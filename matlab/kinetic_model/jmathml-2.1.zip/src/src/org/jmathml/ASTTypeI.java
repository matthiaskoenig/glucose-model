package org.jmathml;

public interface ASTTypeI {
	public String getString();

}
