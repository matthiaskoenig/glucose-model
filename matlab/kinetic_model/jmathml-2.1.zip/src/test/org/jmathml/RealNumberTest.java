package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RealNumberTest {
    ASTNumber doub = ASTNumber.createNumber(12.0d);
    ASTNumber intie = ASTNumber.createNumber(12);
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetString() {
		assertEquals("12.0", doub.getString());
		assertEquals("12", intie.getString());
	}

	@Test
	public void testGetValue() {
		assertEquals(12.0d, doub.getValue(),ASTNodeStub.TOLERANCE);
		assertEquals(12.0d, intie.getValue(),ASTNodeStub.TOLERANCE);
	}

	



	@Test
	(expected=UnsupportedOperationException.class)
	public void testGetDenominator() {
		doub.getDenominator();
	}
	@Test
	(expected=UnsupportedOperationException.class)
	public void testGetNumerator() {
		doub.getNumerator();
	}

	@Test
	public void testRationalNumber() {
		assertFalse(doub.isRational());
		assertFalse(intie.isRational());
	}
	
	@Test
	public void testIsInteger() {
		assertFalse(doub.isInteger());
		assertTrue(intie.isInteger());
	}

}
