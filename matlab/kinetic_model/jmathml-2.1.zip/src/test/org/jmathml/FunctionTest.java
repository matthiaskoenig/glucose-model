package org.jmathml;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.jmathml.ASTFunction.ASTFunctionType;
import org.jmathml.ASTFunction.ASTRoot;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FunctionTest {
	ASTFunction nodeSin = ASTFunction.createFunctionNode(ASTFunctionType.SIN);
	ASTFunction nodeCos = ASTFunction.createFunctionNode(ASTFunctionType.COS);
	ASTFunction nodeTan = ASTFunction.createFunctionNode(ASTFunctionType.TAN);
	ASTFunction nodeASin = ASTFunction.createFunctionNode(ASTFunctionType.ARCSIN);
	ASTFunction nodeSec = ASTFunction.createFunctionNode(ASTFunctionType.SEC);
	ASTFunction nodeCoSec = ASTFunction.createFunctionNode(ASTFunctionType.COSEC);
	ASTFunction nodeSin2 = ASTFunction.createFunctionNode(ASTFunctionType.SIN);
	ASTFunction nodeCot = ASTFunction.createFunctionNode(ASTFunctionType.COT);
	ASTFunction nodeCosh = ASTFunction.createFunctionNode(ASTFunctionType.COSH);
	ASTFunction nodesinh = ASTFunction.createFunctionNode(ASTFunctionType.SINH);
	ASTFunction tanh = ASTFunction.createFunctionNode(ASTFunctionType.TANH);
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testEvaluateSin() {
		nodeSin.addChildNode(ASTNumber.createNumber(Math.PI / 2));
		assertEquals(1d, nodeSin.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
		nodeSin2.addChildNode(createTreenode());
		assertEquals(1d, nodeSin2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateSinh() {
		nodesinh.addChildNode(ASTNumber.createNumber(0));
		assertEquals(0, nodesinh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
		
	}
	
	@Test
	public void testEvaluateCos() {
		nodeCos.addChildNode(ASTNumber.createNumber(0));
		assertEquals(1d, nodeCos.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateTan() {
		nodeTan.addChildNode(ASTNumber.createNumber(Math.PI));
		assertEquals(0d, nodeTan.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateTanh() {
		tanh.addChildNode(ASTNumber.createNumber(0));
		assertEquals(0d, tanh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
		tanh = ASTFunction.createFunctionNode(ASTFunctionType.TANH);
		tanh.addChildNode(ASTNumber.createNumber(100));
		assertEquals(1d, tanh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
		tanh = ASTFunction.createFunctionNode(ASTFunctionType.TANH);
		tanh.addChildNode(ASTNumber.createNumber(-100));
		assertEquals(-1d, tanh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
		tanh = ASTFunction.createFunctionNode(ASTFunctionType.TANH);
		ASTCi var = new ASTCi("x");
		EvaluationContext ec = new EvaluationContext();
		tanh.addChildNode(var);
		for (double i = -1000; i < 1000; i+=10){
			ec.setValueFor("x", i);
			ASTNumber num = tanh.evaluate(ec);
			
			assertFalse(Double.isNaN(num.getValue()));
			assertTrue(num.getValue()<=1 && num.getValue()>=-1);
		}

	}
	
	
	
	@Test
	public void testEvaluateSecReturnsPosInfinityIfQuotientEValuatesToZero() {
		nodeSec.addChildNode(ASTNumber.createNumber(Math.PI/2));
		assertEquals(Double.POSITIVE_INFINITY, nodeSec.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateSec() {
		nodeSec.addChildNode(ASTNumber.createNumber(0));
		assertEquals(1, nodeSec.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCosh() {
		nodeCosh.addChildNode(ASTNumber.createNumber(Math.E));
		assertEquals(7.61012514, nodeCosh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCosh2() {
		nodeCosh.addChildNode(ASTNumber.createNumber(0));
		assertEquals(1, nodeCosh.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCosecReturnsPosInfinityIfQuotientEValuatesToZero() {
		nodeCoSec.addChildNode(ASTNumber.createNumber(0));
		assertEquals(Double.POSITIVE_INFINITY, nodeCoSec.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCosec() {
		nodeCoSec.addChildNode(ASTNumber.createNumber(Math.PI/2));
		assertEquals(1, nodeCoSec.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCotReturnsPosInfinityIfQuotientEValuatesToZero() {
	nodeCot.addChildNode(ASTNumber.createNumber(0));
		assertEquals(Double.POSITIVE_INFINITY, nodeCot.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCot1() {
		nodeCot.addChildNode(ASTNumber.createNumber(Math.PI/4));
		assertEquals(1, nodeCot.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateCot2() {
		nodeCot.addChildNode(ASTNumber.createNumber(Math.PI/6));
		assertEquals(Math.sqrt(3), nodeCot.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateLogBase10() {
		ASTFunction nodeLog = ASTFunction.createFunctionNode(ASTFunctionType.LOG);
		nodeLog.addChildNode(ASTNumber.createNumber(100d));
		assertEquals(2, nodeLog.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateLogOtherBase() {
		ASTFunction nodeLog = ASTFunction.createASTLog(4);
		nodeLog.addChildNode(ASTNumber.createNumber(256));
		assertEquals(4, nodeLog.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	(expected=IllegalArgumentException.class)
	public void testCreateLogOtherBaseThrowsIAEifBaseLessThan1() {
	 ASTFunction.createASTLog(0);
		
	}
	

	
	@Test
	public void testEvaluateFactorial() {
		ASTFunction fac = ASTFunction.createFunctionNode(ASTFunctionType.FACTORIAL);
		fac.addChildNode(ASTNumber.createNumber(5)); // invalid log base
		assertEquals(120, fac.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testEvaluateFactorialWithDoubleWorks() {
		ASTFunction fac = ASTFunction.createFunctionNode(ASTFunctionType.FACTORIAL);
		fac.addChildNode(ASTNumber.createNumber(5.4)); // invalid log base
		assertEquals(120, fac.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testSQRT() {
		ASTRoot nodesqrt = ASTFunction.createASTRoot(2);
		nodesqrt.addChildNode(ASTNumber.createNumber(36));
		assertEquals(6, nodesqrt.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testRootWithOneChildIsSqRoot() {
		ASTFunction nodesqrt = ASTFunction.createFunctionNode(ASTFunctionType.ROOT);
		nodesqrt.addChildNode(ASTNumber.createNumber(25));
		assertEquals(5, nodesqrt.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testCubeRoot() {
		ASTRoot nodeCubeRt = ASTFunction.createASTRoot(3);
		nodeCubeRt.addChildNode(ASTNumber.createNumber(27));
		assertEquals(3, nodeCubeRt.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testNthRoot() {
		ASTRoot nthRt = ASTFunction.createASTRoot(5);
		nthRt.addChildNode(ASTNumber.createNumber(3125)); //number
		assertEquals(5, nthRt.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTTest.TOLERANCE);
	}
	
	@Test
	public void testExp() {
		ASTFunction exp = ASTFunction.createFunctionNode(ASTFunctionType.EXP);
		assertEquals(ASTFunctionType.EXP, exp.getType());
		exp.addChildNode(ASTNumber.createNumber(5)); 
		assertEquals(Math.exp(5), exp.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), ASTTest.TOLERANCE);
		assertTrue(exp.hasCorrectNumberChildren());
	}
	@Test
	public void testLn() {
		ASTFunction ln = ASTFunction.createFunctionNode(ASTFunctionType.LN);
		assertEquals(ASTFunctionType.LN, ln.getType());
		ln.addChildNode(ASTNumber.createNumber(Math.E)); 
		assertEquals(1, ln.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), ASTTest.TOLERANCE);
		assertTrue(ln.hasCorrectNumberChildren());
	}
	
	@Test
	public void testCeil() {
		ASTFunction ceil = ASTFunction.createFunctionNode(ASTFunctionType.CEIL);
		assertEquals(ASTFunctionType.CEIL, ceil.getType());
		ceil.addChildNode(ASTNumber.createNumber(Math.E)); 
		assertEquals(3, ceil.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), ASTTest.TOLERANCE);
		assertTrue(ceil.hasCorrectNumberChildren());
	}
	@Test
	public void testFloor() {
		ASTFunction floor = ASTFunction.createFunctionNode(ASTFunctionType.FLOOR);
		assertEquals(ASTFunctionType.FLOOR, floor.getType());
		floor.addChildNode(ASTNumber.createNumber(Math.E)); 
		assertEquals(2, floor.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), ASTTest.TOLERANCE);
		assertTrue(floor.hasCorrectNumberChildren());
	}
	@Test
	public void testAbs() {
		ASTFunction abs = ASTFunction.createFunctionNode(ASTFunctionType.ABS);
		assertEquals(ASTFunctionType.ABS, abs.getType());
		abs.addChildNode(ASTNumber.createNumber(Math.E * -1)); 
		assertEquals(Math.E, abs.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), ASTTest.TOLERANCE);
		assertTrue(abs.hasCorrectNumberChildren());
	}

	private ASTNode createTreenode() {
	ASTNode times = new ASTTimes();
	times.addChildNode(ASTNumber.createNumber(Math.PI/4));
	times.addChildNode(ASTNumber.createNumber(2d));
	return times;
	}
	
	@Test
	public void testShouldHaveOneChild(){
		assertFalse(nodeSin.hasCorrectNumberChildren());
		nodeSin.addChildNode(new ASTNodeStub()); // 1 now
		assertTrue(nodeSin.hasCorrectNumberChildren());
		nodeSin.addChildNode(new ASTNodeStub()); // 2 now
		assertFalse(nodeSin.hasCorrectNumberChildren());
		nodeSin=ASTFunction.createFunctionNode(ASTFunctionType.SIN);
		assertFalse(nodeSin.hasCorrectNumberChildren());
		
	}

}
