package org.jmathml;

import static org.junit.Assert.assertEquals;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jmathml.ASTFunction.ASTFunctionType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class UserGuideExamplesTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreation1() {
		ASTPlus plus = new ASTPlus();
		plus.addChildNode(ASTNumber.createNumber(2));
		plus.addChildNode(ASTNumber.createNumber(3));
		assertEquals(5, plus.evaluate().getValue(),0.001);
	}

	@Test
	public void testCreation2() {
		ASTFunction sin = ASTFunction.createFunctionNode(ASTFunctionType.SIN);
		ASTPlus plus = new ASTPlus();
		ASTDivide div = new ASTDivide();
		div.addChildNode(ASTNumber.PI());
		div.addChildNode(ASTNumber.createNumber(2));

		plus.addChildNode(new ASTCi("x"));
		plus.addChildNode(div);
		sin.addChildNode(plus);

		plus.removeChildAtIndex(0);
		// or
		plus.removeChildNode(div);

		sin.replaceChild(plus, new ASTCi("x"));

		sin.firstChild();
		sin.getChildAtIndex(0);
		sin.getChildren();
		sin.getRightChild();
		sin.getNumChildren();

	}

	@Test
	public void testReadFromString() {
		TextToASTNodeMathParser2 parser = new TextToASTNodeMathParser2();
		ASTRootNode root = new ASTRootNode();
		parser.parseString("sin (pi/2)", root);
		double result = root.evaluate().getValue();
		assertEquals(1, result,0.001);

	}
	@Test
	public void testEvaluateVars() {
	
	EvaluationContext ec = new EvaluationContext();
	ec.setValueFor("a", Math.PI / 2);
	ec.setValueFor("b", 0d);
	
	ASTNode test = getTestExample(); // returns ASTNode for sin(a) + cos(b);
	if(test.canEvaluate(ec)) {
		double result = test.evaluate(ec).getValue();
		assertEquals(2, result,0.000001);
	}
	}
	
	
	@Test
	public void testToMathML() {
		ASTToXMLElementVisitor visitor = new ASTToXMLElementVisitor();
		ASTNode root = getTestExample();
		root.accept(visitor);
		
		// now we use some boiler plate JDom code to get the XML as a String: 
		System.out.println(getElementString(visitor.getElement()));
	}
	
	String getElementString (org.jdom.Element node) {
		Document mathDoc = new Document();
		mathDoc.setRootElement(node);
		String xmlString = xmlToString(mathDoc, false);
		return xmlString;
	   }
	
	
	String xmlToString(Document xmlDoc, boolean bTrimAllWhiteSpace) {
		XMLOutputter xmlOut = new XMLOutputter(Format.getPrettyFormat());
		
		return xmlOut.outputString(xmlDoc);		        
	}
	

	private ASTNode getTestExample() {
		TextToASTNodeMathParser2 parser = new TextToASTNodeMathParser2();
		ASTRootNode root = new ASTRootNode();
		return parser.parseString("sin (a) + cos(b)", root);
	}

}
