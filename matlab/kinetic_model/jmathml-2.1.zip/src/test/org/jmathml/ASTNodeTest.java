package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.jmathml.ASTNode.ASTType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTNodeTest {
    ASTNode root, n2, n3;
    
    
	@Before
	public void setUp() throws Exception {
		root = new ASTNodeStub();
		n2 = new ASTNodeStub();
		n3 = new ASTNodeStub();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetLevel() {
		assertEquals(0, root.getLevel());
		root.addChildNode(n2);
		assertEquals(1, n2.getLevel());
		n2.addChildNode(n3);
		assertEquals(2, n3.getLevel());
		
	}

	@Test
	public void testAddChildNode() {
		assertTrue(root.addChildNode(n2));
		assertTrue(n2.getParentNode().equals(root));
	}
	
	@Test
	public void testRemoveChildNode() {
		root.addChildNode(n2);
		root.removeChildNode(n2);
		assertNull(n2.getParentNode());
		assertEquals(0,root.getNumChildren());
		
	}
	
	@Test
	public void testRemoveChildNodeAtIndexReturnsRemovedNode() {
		root.addChildNode(n2);
		root.addChildNode(n3);
		ASTNode removed= root.removeChildAtIndex(0);
		assertEquals(n2, removed);	
		ASTNode removed2= root.removeChildAtIndex(0);
		assertEquals(n3, removed2);	
	}
	@Test
	(expected=IllegalArgumentException.class)
	public void testRemoveChildNodeAtIndexThrowsExceptionIfIndexOutofRange() {
		root.addChildNode(n2);
		root.addChildNode(n3);
		root.removeChildAtIndex(root.getNumChildren());// index out of range
			
	}
	
	@Test
	(expected=IllegalArgumentException.class)
	public void testCannotAddNullChild() {
		root.addChildNode(null);
	}

	@Test
	public void testGetParentNode() {
		assertNull(root.getParentNode());
	}

	@Test
	public void testGetChildren() {
		assertTrue(root.getChildren() != null);
		assertTrue(root.getChildren().isEmpty());
		root.addChildNode(n2);
		assertTrue(root.getChildren().size()==1);
	}
	
	@Test
	public void testGetRightChild() {
		assertNull(root.getRightChild());
		root.addChildNode(n2);
		root.addChildNode(n3);
		assertEquals(n3, root.getRightChild());
	}

	@Test
	(expected=IllegalStateException.class)
	public void testGetFirstChildThrowsISEIfnoChildren() {
		root.firstChild();
	}

	@Test
	(expected=IllegalArgumentException.class)
	public void testGetChildAtIndex() {
		root.getChildAtIndex(0);
	}

	@Test
	public void testGetIndex() {
		//n2 & n3 are siblings
		root.addChildNode(n2);
		root.addChildNode(n3);
		assertEquals(0, n2.getIndex());
		assertEquals(1, n3.getIndex());
	}

	@Test
	public void testIsLeaf() {
		assertTrue(root.isLeaf());
		root.addChildNode(n2);
		assertFalse(root.isLeaf());
	}
	
	@Test
	public void testAddChildAtIndex(){
		root.addChildNodeAt(0, n2);
		root.addChildNodeAt(0, n3);
		assertEquals(n3,root.firstChild());
		assertEquals(n2,root.getChildAtIndex(1));
	}
	
	@Test
	(expected=IndexOutOfBoundsException.class)
	public void testAddChildAtIndexThrowsIndexOutOfBoundsException(){
		int ILLEGAL_INDEX=1;
		root.addChildNodeAt(ILLEGAL_INDEX, n2);
	}
	
	@Test
	public void testReplaceChildBasic() {
		// root/ n2, n3 -> root / toReplace, n3
		root.addChildNode(n2);
		root.addChildNode(n3);
		ASTNode toReplace= new ASTNodeStub();
		assertTrue(root.replaceChild(n2, toReplace));
		
		assertEquals(toReplace, root.firstChild());
		assertFalse(root.getChildren().contains(n2));
		assertEquals(2, root.getNumChildren());
		assertEquals(n3, root.getChildAtIndex(1));
		assertEquals(0,toReplace.getIndex());
		assertNull(n2.getParentNode());
	}
	
	@Test
	(expected=IllegalArgumentException.class)
	public void testCannotReplaceChildWithNull() {
		// root/ n2, n3 -> root / toReplace, n3
		root.addChildNode(n2);
		root.addChildNode(n3);
		root.replaceChild(n2, null);
		
		
	}
	
	@Test
	public void testCanEvaluate(){
		assertTrue(root.canEvaluate(IEvaluationContext.NULL_CONTEXT));
	}
	
	@Test
	public void testCantEvaluateUnknownIdentifier(){
		root.addChildNode(new ASTCi("a"));
		assertFalse(root.canEvaluate(IEvaluationContext.NULL_CONTEXT));
	}
	
	final IEvaluationContext OKContext= new IEvaluationContext() {
		public boolean hasValueFor(String identifier) {
			return true;
		}
		public Iterable<Double> getValueFor(String identifier) {
			return Arrays.asList(0d);
		}
	};
	
	final IEvaluationContext NotOKContext= new IEvaluationContext() {
		public boolean hasValueFor(String identifier) {
			return false;
		}
		public Iterable<Double> getValueFor(String identifier) {
			return Arrays.asList(0d);
		}
	};
	
	@Test
	public void testEvaluateNestedIdentifier(){
		root.addChildNode(n2);
		n2.addChildNode(n3);
		ASTNode var = new ASTCi("a");
		n3.addChildNode(var);
		assertTrue(root.canEvaluate(OKContext));
		assertFalse(root.canEvaluate(NotOKContext));
	}
	
	@Test
	public void testEvaluateNestedIdentifier2(){
		root.addChildNode(n2);
		n2.addChildNode(n3);
		Map<String, Iterable<Double>> vars = new HashMap<String, Iterable<Double>>();
		vars.put("a", Arrays.asList(1d));
		EvaluationContext ec = new EvaluationContext(vars);

		
		ASTNode var = new ASTCi("a");
		n3.addChildNode(var);
		assertTrue(root.canEvaluate(ec));
		n3.addChildNode(new ASTCi("b"));
		assertFalse(root.canEvaluate(ec));
		
	}
	
	@Test
	public void testASTEnums(){
		for (ASTType t: ASTType.values()){
			System.out.println(t.toString().toLowerCase());
		}
	}
	
	@Test
	public void testGetIentifiersFalseIfNoCi(){
		root.addChildNode(n2);
		n2.addChildNode(n3);
		assertEquals(0,root.getIdentifiers().size());
	
	}
	
	@Test
	public void testGetIdentifiers(){
		root.addChildNode(n2);
		n2.addChildNode(n3);
		n2.addChildNode(new ASTCi("y"));
		n3.addChildNode(new ASTCi("x"));
		assertEquals(2,root.getIdentifiers().size());
	
	}
	
	@Test
	public void testGetIdentifiersUniqueVersusNotUnique(){
		root.addChildNode(n2);
		n2.addChildNode(n3);
		n2.addChildNode(new ASTCi("y"));
		n2.addChildNode(new ASTCi("y")); // duplicate value
		assertEquals(2,root.getIdentifiers().size());
		assertEquals(1,root.getUniqueIdentifiers().size());
	
	}
	
	

	
}
