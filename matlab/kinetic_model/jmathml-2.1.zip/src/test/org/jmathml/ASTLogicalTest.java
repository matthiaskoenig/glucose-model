package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmathml.ASTLogical.ASTLogicalType;
import org.jmathml.ASTNumber.ASTNumberType;
import org.jmathml.ASTRelational.ASTRelationalType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTLogicalTest {
    ASTNode and, or, not, xor;
	@Before
	public void setUp() throws Exception {
		and = new ASTLogical(ASTLogicalType.AND);
		or = new ASTLogical(ASTLogicalType.OR);
		not = new ASTLogical(ASTLogicalType.NOT);
		xor = new ASTLogical(ASTLogicalType.XOR);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetString() {
		assertEquals("&&", and.getString());
		assertEquals("||", or.getString());
		assertEquals("!", not.getString());
		assertEquals("^", xor.getString());
	}
	
	@Test
	public void testGetName() {
		assertEquals("and", and.getName());
		assertEquals("or", or.getName());
		assertEquals("not", not.getName());
		assertEquals("xor", xor.getName());
	}

	@Test
	public void testNotIsUnary(){
		assertFalse(not.hasCorrectNumberChildren());
		not.addChildNode(new ASTRelational(ASTRelationalType.GEQ));
		assertTrue(not.hasCorrectNumberChildren());
	}
	
	@Test
	public void testAndIsNary(){
		assertFalse(and.hasCorrectNumberChildren());
		and.addChildNode(new ASTRelational(ASTRelationalType.GEQ));
		assertFalse(and.hasCorrectNumberChildren());
		and.addChildNode(new ASTRelational(ASTRelationalType.GEQ));
		assertTrue(and.hasCorrectNumberChildren());
	} 
	
	@Test
	public void testOrIsNary(){
		assertFalse(or.hasCorrectNumberChildren());
		or.addChildNode(new ASTRelational(ASTRelationalType.GEQ));
		assertFalse(or.hasCorrectNumberChildren());
		or.addChildNode(new ASTRelational(ASTRelationalType.GEQ));
		assertTrue(or.hasCorrectNumberChildren());
	} 

	@Test
	public void testIsLogical() {
		assertTrue(and.isLogical());
		assertTrue(or.isLogical());
		assertTrue(not.isLogical());
		assertTrue(xor.isLogical());
	}
	
	@Test public void testToString(){
		ASTNode LHIeq= new ASTRelational(ASTRelationalType.LT);
		LHIeq.addChildNode(ASTNumber.createNumber(2.0));
		LHIeq.addChildNode(ASTNumber.createNumber(3.0));
		
		ASTNode RHIeq= new ASTRelational(ASTRelationalType.GT);
		RHIeq.addChildNode(ASTNumber.createNumber(10.0));
		RHIeq.addChildNode(ASTNumber.createNumber(1.0));
		ASTNode root = new ASTLogical(ASTLogicalType.OR);
		ASTNode c1 = new ASTLogical(ASTLogicalType.OR);
		c1.addChildNode(LHIeq);
		c1.addChildNode(RHIeq);
		
		
		ASTNode c2 = new ASTLogical(ASTLogicalType.AND);
		ASTNode LH2eq= new ASTRelational(ASTRelationalType.LT);
		LH2eq.addChildNode(ASTNumber.createNumber(2.0));
		LH2eq.addChildNode(ASTNumber.createNumber(13.0));
		
		ASTNode RH2eq= new ASTRelational(ASTRelationalType.GT);
		RH2eq.addChildNode(ASTNumber.createNumber(10.0));
		RH2eq.addChildNode(ASTNumber.createNumber(7.0));
		c2.addChildNode(LH2eq);
		c2.addChildNode(RH2eq);
		
		root.addChildNode(c1);
		root.addChildNode(c2);
		
		List<ASTNode> bottomlogEqs = new ArrayList<ASTNode>();
		populateBottomLogicalNodes(root,bottomlogEqs);
		assertEquals(2, bottomlogEqs.size());
		

		
		popList(bottomlogEqs);
		System.out.println(root.getUserData());
		
		bottomlogEqs.clear();
		
		populateBottomLogicalNodes(c1,bottomlogEqs);
		popList(bottomlogEqs);
		System.out.println(new BooleanToString().getString(c1));
		
		bottomlogEqs.clear();
		populateBottomLogicalNodes(c2,bottomlogEqs);
		popList(bottomlogEqs);
		System.out.println(c2.getUserData());
		
		bottomlogEqs.clear();
		populateBottomLogicalNodes(RH2eq,bottomlogEqs);
		popList(bottomlogEqs);
		System.out.println(RH2eq.getUserData());
		
		
	}

	private void populateBottomLogicalNodes(ASTNode root,List<ASTNode> bottomlogEqs) {
		boolean hasAnyLogicalChildren= false;
		for (ASTNode node: root.getChildren()){
			if(node.isLogical()){
				hasAnyLogicalChildren=true;
				populateBottomLogicalNodes(node, bottomlogEqs);
			}
		}	
	    if (!hasAnyLogicalChildren){
	    	bottomlogEqs.add(root);
	    }
		
		
	}
	
	@Test
	public void testEvaluatAnd(){
		ASTNode get = new ASTRelational(ASTRelationalType.GEQ);
		ASTNode eq = new ASTRelational(ASTRelationalType.EQ);
		get.addChildNode(ASTNumber.createNumber(4));
		get.addChildNode(ASTNumber.createNumber(3));
		eq.addChildNode(ASTNumber.createNumber(2));
		eq.addChildNode(ASTNumber.createNumber(2));
		and.addChildNode(get);
		and.addChildNode(eq);
		assertEquals(ASTNumberType.TRUE, and.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		// now make untrue
		eq.replaceChild(eq.firstChild(), ASTNumber.createNumber(444));
		assertEquals(ASTNumberType.FALSE, and.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateOr(){
		ASTNode get = new ASTRelational(ASTRelationalType.GEQ);
		ASTNode eq = new ASTRelational(ASTRelationalType.EQ);
		get.addChildNode(ASTNumber.createNumber(4));
		get.addChildNode(ASTNumber.createNumber(3));
		eq.addChildNode(ASTNumber.createNumber(2));
		eq.addChildNode(ASTNumber.createNumber(2));
		or.addChildNode(get);
		or.addChildNode(eq);
		//(4 > 3) || (2 == 2)
		assertEquals(ASTNumberType.TRUE, or.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		// now make1  untrue
		//(4 > 3) || (-1 == 2)
		eq.replaceChild(eq.firstChild(), ASTNumber.createNumber(-444));
		assertEquals(ASTNumberType.TRUE, or.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		// now make both untrue
		//(-444 > 3) || (-1 == 2)
		get.replaceChild(get.firstChild(), ASTNumber.createNumber(-1));
		assertEquals(ASTNumberType.FALSE, or.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateXOr(){
		ASTNode get = new ASTRelational(ASTRelationalType.GEQ);
		ASTNode eq = new ASTRelational(ASTRelationalType.EQ);
		get.addChildNode(ASTNumber.createNumber(4));
		get.addChildNode(ASTNumber.createNumber(3));
		eq.addChildNode(ASTNumber.createNumber(2));
		eq.addChildNode(ASTNumber.createNumber(2));
		xor.addChildNode(get);
		xor.addChildNode(eq);
		//(4 > 3) || (2 == 2) // both true, xor = false
		assertEquals(ASTNumberType.FALSE, xor.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		// now make1  untrue
		//(4 > 3) || (-1 == 2)
		eq.replaceChild(eq.firstChild(), ASTNumber.createNumber(-444));
		assertEquals(ASTNumberType.TRUE, xor.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		// now make both untrue
		//(-444 > 3) || (-1 == 2)
		get.replaceChild(get.firstChild(), ASTNumber.createNumber(-1));
		assertEquals(ASTNumberType.FALSE, xor.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateNot(){
		ASTNode get = new ASTRelational(ASTRelationalType.GEQ);
		get.addChildNode(ASTNumber.createNumber(4));
		get.addChildNode(ASTNumber.createNumber(3));
	
		//! ( 4 > 3) == false
		not.addChildNode(get);
		assertEquals(ASTNumberType.FALSE, not.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
		
		//! ( -2 > 3) == true
		get.replaceChild(get.firstChild(), ASTNumber.createNumber(-2));
		assertEquals(ASTNumberType.TRUE, not.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}

	private void popList(List<ASTNode> bottomlogEqs) {
		
		List <ASTNode> parents = new ArrayList<ASTNode>();
		for (ASTNode bottom : bottomlogEqs){
			StringBuffer sb = new StringBuffer();
		
			if(bottom.isRelational()){
				createInequality(sb, bottom);
			
				bottom.setUserData(sb.toString());
			    continue;
			}
			sb.append("(");
			for (ASTNode ineq: bottom.getChildren()){
				if(ineq.getUserData()!=null){
					sb.append(ineq.getUserData());
					if (ineq != bottom.getRightChild()){
						  sb.append(" " + ineq.getParentNode().getString()+ " "); // ineq operator
					  }
				} else {
				createInequality(sb, ineq);
					if (ineq != bottom.getRightChild()){
						sb.append(" " +ineq.getParentNode().getString() + " "); // logical operator
					}
				}
			}
			sb.append(")");
			bottom.setUserData(sb.toString());
			if(bottom.getParentNode()!=null &&!parents.contains(bottom.getParentNode())){
				parents.add(bottom.getParentNode());
			}
		}
		//guard for top of tree, to prevent infinite recursion.
		if (!parents.isEmpty()) {
			popList(parents);
		}
		
		
	}

	private void createInequality(StringBuffer sb, ASTNode ineq) {
		// this section is for populating inequliity
		for (ASTNode math: ineq.getChildren()) { // 2 nodes  f
		  sb.append(new FormulaFormatter().formulaToString(math));
		  if (math != ineq.getRightChild()){
			  sb.append(" " + math.getParentNode().getString()+ " "); // ineq operator
		  }
		}
	}
	
	

}
