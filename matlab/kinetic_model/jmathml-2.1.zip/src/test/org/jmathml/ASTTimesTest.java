package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTTimesTest {

	ASTNode astTimes = new ASTTimes();
	
	@Before
	public void setUp() throws Exception {
		astTimes.addChildNode(ASTNumber.createNumber(3d));
		astTimes.addChildNode(ASTNumber.createNumber(7d));
	}
	

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetName() {
		assertEquals(ASTTimes.TIMES_NAME, astTimes.getName());
	}

	@Test
	public void testGetString() {
		assertEquals( "*", astTimes.getString());
	}

	@Test
	public void testEvaluate() {
		assertEquals(21d, astTimes.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}

	@Test
	public void testShouldHaveAtLeastTwoChildren(){
		assertTrue(astTimes.hasCorrectNumberChildren());
		astTimes.addChildNode(new ASTNodeStub()); // 3 now
		assertTrue(astTimes.hasCorrectNumberChildren());
		
		astTimes= new ASTTimes();
		assertFalse(astTimes.hasCorrectNumberChildren());
		
		
	}
}
