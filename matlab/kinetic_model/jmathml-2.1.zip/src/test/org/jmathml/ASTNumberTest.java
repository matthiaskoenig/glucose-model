package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTNumberTest {

	ASTNode astNumber = ASTNumber.createNumber(5d);
	
	@Before
	public void setUp() throws Exception {
	
	}
	

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetName() {
		assertEquals("5.0", astNumber.getName());
	}

	@Test
	public void testGetString() {
		assertEquals("5.0", astNumber.getString());
	}

	@Test
	public void testEvaluate() {
		assertEquals(astNumber, astNumber.evaluate(IEvaluationContext.NULL_CONTEXT));
	}
	@Test
	(expected=IllegalArgumentException.class)
	public void testCreateRationalNumberThrowsIAEIfdenominatorIsZero() {
		int ANYNUMBER=45;
		ASTNumber.createNumber(ANYNUMBER, 0);
	}
	
	@Test
	public void testFalseIsFalse(){
		assertTrue(ASTNumber.FALSE().isFalse());
		assertFalse(ASTNumber.FALSE().isTruth());
	}
	
	@Test
	public void testE(){
		assertEquals(Math.E, ASTNumber.E().evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
		
	}
	
	@Test
	public void testPI(){
		assertEquals(Math.PI, ASTNumber.PI().evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public void testNaN(){
		assertEquals(Double.NaN, ASTNumber.NaN().evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public void testInfinity(){
		assertEquals(Double.POSITIVE_INFINITY, ASTNumber.INFINITY().evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}

}
