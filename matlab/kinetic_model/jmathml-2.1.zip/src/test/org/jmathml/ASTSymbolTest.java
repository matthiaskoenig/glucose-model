package org.jmathml;


import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTSymbolTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testgetNameIsSymbolName(){
		ASTSymbol symbol=createSymbolFunc();
		assertTrue(symbol.isSymbol());
		assertEquals("time", symbol.getName());
		assertEquals("text", symbol.getEncoding());
		assertEquals("http:///www.time.com", symbol.getDefinitionURL());
	}
	
	@Test
	public void testgetNumChildren(){
		ASTSymbol	symbol=createSymbolFunc();
		assertTrue(symbol.hasCorrectNumberChildren()); //0 is correct
	}
	
	@Test
	public void testSymbolValue(){
		ASTSymbol	symbol=createSymbolVar();
		assertTrue(symbol.hasCorrectNumberChildren()); //0 is correct
		assertTrue(symbol.isSymbolValue());
		assertFalse(symbol.isSymbolFunction());
	}
	
	@Test
	public void  testEvaluate(){
		ASTSymbol symbol=createSymbolFunc();
		assertTrue(symbol.isSymbolFunction());
		Map<String, Iterable<Double>>ids = new HashMap<String, Iterable<Double>>();
		ids.put("time", Arrays.asList(3d));
		assertEquals(3, symbol.evaluate(new EvaluationContext(ids)).getValue(), 0.001);
		
	}
	
	 ASTSymbol createSymbolFunc(){
		 ASTSymbol symbol = new ASTSymbol("time");
		symbol.setEncoding("text");
		symbol.setDefinitionURL("http:///www.time.com");
		return symbol;
	}
	 
	 ASTSymbol createSymbolVar(){
		 ASTSymbol symbol = new ASTSymbol("time",true);
		symbol.setEncoding("text");
		symbol.setDefinitionURL("http:///www.time.com");
		return symbol;
	}

}
