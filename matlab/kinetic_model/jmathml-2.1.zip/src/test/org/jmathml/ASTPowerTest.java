package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTPowerTest {
    private ASTPower power=new ASTPower();
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testHasCorrectNumberChildren() {
		addDefaultChildNodes();
		assertTrue(power.hasCorrectNumberChildren());
		power.addChildNode(ASTNumber.createNumber(22));/// too many nodes
		assertFalse(power.hasCorrectNumberChildren());
		
		
	}

	private void addDefaultChildNodes() {
		power.addChildNode(ASTNumber.createNumber(3));
		power.addChildNode(ASTNumber.createNumber(3));
	}

	

	@Test
	public final void testIsPower() {
		assertTrue(power.isPower());
	}
	
	@Test
	public final void testEvaluate() {
		addDefaultChildNodes();
		assertTrue(power.canEvaluate(IEvaluationContext.NULL_CONTEXT));
		assertEquals(27, power.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		
	}

}
