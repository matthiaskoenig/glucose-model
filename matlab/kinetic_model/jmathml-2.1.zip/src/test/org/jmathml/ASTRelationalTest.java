package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.jmathml.ASTRelational.ASTRelationalType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTRelationalTest {
    ASTNode relEquals, relNotEquals, relGtOrEqual,rel4,relGt,rel6;
    private List<ASTNode> nodes; 
	@Before
	public void setUp() throws Exception {
		relEquals = new ASTRelational(ASTRelationalType.EQ);
		relNotEquals = new ASTRelational(ASTRelationalType.NEQ);
		relGtOrEqual = new ASTRelational(ASTRelationalType.GEQ);
		rel4 = new ASTRelational(ASTRelationalType.LEQ);
		relGt = new ASTRelational(ASTRelationalType.GT);
		rel6 = new ASTRelational(ASTRelationalType.LT);
		nodes = Arrays.asList(new ASTNode[]{relEquals, relNotEquals, relGtOrEqual,rel4,relGt,rel6});
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetName() {
		assertEquals("==", relEquals.getString());
		assertEquals("!=", relNotEquals.getString());
		assertEquals(">=", relGtOrEqual.getString());
		assertEquals("<=", rel4.getString());
		assertEquals(">", relGt.getString());
		assertEquals("<", rel6.getString());
	}
	
	@Test
	public void testGetString() {
		assertEquals("eq", relEquals.getName());
		assertEquals("neq", relNotEquals.getName());
		assertEquals("geq", relGtOrEqual.getName());
		assertEquals("leq", rel4.getName());
		assertEquals("gt", relGt.getName());
		assertEquals("lt", rel6.getName());
	}

	@Test
	public void testEqualsHasAtLEastTwoChildren() {
		// test Equ
		assertFalse(relEquals.hasCorrectNumberChildren());// 0
		relEquals.addChildNode(ASTNumber.createNumber(2,3));
		assertFalse(relEquals.hasCorrectNumberChildren());// 1
		relEquals.addChildNode(ASTNumber.createNumber(2,3));
		assertTrue(relEquals.hasCorrectNumberChildren());// 2
		relEquals.addChildNode(ASTNumber.createNumber(2,3));
		assertTrue(relEquals.hasCorrectNumberChildren());// 3
	}

	@Test
	public void testIsRelational() {
		for (ASTNode n :nodes){
			assertTrue(n.isRelational());
		}
	}
	
	@Test
	public void testEvaluateEqualsFalseForBinaryRelation(){
		relEquals.addChildNode(ASTNumber.createNumber(2));
		relEquals.addChildNode(ASTNumber.createNumber(3));
		assertEquals(ASTNumber.ASTNumberType.FALSE, relEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateEqualsTrueForBinaryRelationBetweenIntgers(){
		relEquals.addChildNode(ASTNumber.createNumber(2));
		relEquals.addChildNode(ASTNumber.createNumber(2));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateEqualsTrueForBinaryRelationBetweenRationalNums(){
		relEquals.addChildNode(ASTNumber.createNumber(2,7));
		relEquals.addChildNode(ASTNumber.createNumber(2,7));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateEqualsTrueForNaryRelationBetweenRealNums(){
		relEquals.addChildNode(ASTNumber.createNumber(0.267));
		relEquals.addChildNode(ASTNumber.createNumber(0.267));
		relEquals.addChildNode(ASTNumber.createNumber(0.267));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterOrEqualThanTrueForNaryRelationBetweenRealNums(){
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.267));
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265));
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relGtOrEqual.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterOrEqualThanTrueForNaryRelationBetweenEqualNums(){
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265));
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265));
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relGtOrEqual.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterOrEqualThanFalseForBinaryRelationBetweenNonEqualNums(){
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265)); // is not >= 0.267
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.267));
		assertEquals(ASTNumber.ASTNumberType.FALSE, relGtOrEqual.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterOrEqualThanFalseForUnaryRelation(){
		relGtOrEqual.addChildNode(ASTNumber.createNumber(0.265)); 
		assertEquals(ASTNumber.ASTNumberType.FALSE, relGtOrEqual.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterThanFalseForUnaryRelation(){
		relGt.addChildNode(ASTNumber.createNumber(0.265)); 
		assertEquals(ASTNumber.ASTNumberType.FALSE, relGt.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateGreaterThanFalseForBinaryRelationBetweenEqualNums(){
		relGt.addChildNode(ASTNumber.createNumber(0.265)); 
		relGt.addChildNode(ASTNumber.createNumber(0.265));
		assertEquals(ASTNumber.ASTNumberType.FALSE, relGt.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	@Test
	public void testEvaluateGreaterThanTrueForNaryRelationBetweenEqualNums(){
		relGt.addChildNode(ASTNumber.createNumber(0.265)); 
		relGt.addChildNode(ASTNumber.createNumber(0.264));
		relGt.addChildNode(ASTNumber.createNumber(0.263));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relGt.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateNETrueForNaryRelationBetweenEqualNums(){
		relNotEquals.addChildNode(ASTNumber.createNumber(0.265)); 
		relNotEquals.addChildNode(ASTNumber.createNumber(0.264));
		assertEquals(ASTNumber.ASTNumberType.TRUE, relNotEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateNEFalseForNaryRelationBetweenEqualNums(){
		relNotEquals.addChildNode(ASTNumber.createNumber(0.264)); 
		relNotEquals.addChildNode(ASTNumber.createNumber(0.264));
		assertEquals(ASTNumber.ASTNumberType.FALSE, relNotEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	
	@Test
	public void testEvaluateNEFalseForUnaryRelation(){
		relNotEquals.addChildNode(ASTNumber.createNumber(0.264)); 
		assertEquals(ASTNumber.ASTNumberType.FALSE, relNotEquals.evaluate(IEvaluationContext.NULL_CONTEXT).getType());
	}
	

}
