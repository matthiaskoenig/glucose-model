package org.jmathml;


import static org.junit.Assert.assertEquals;

import org.jmathml.ASTFunction.ASTFunctionType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FormulaFormatterTest {
    FormulaFormatter ff;
	@Before
	public void setUp() throws Exception {
		ff= new FormulaFormatter();
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testBinaryPlus(){
		ASTOperator op = new ASTPlus();
		op.addChildNode(ASTNumber.createNumber(4.0));
		op.addChildNode(ASTNumber.createNumber(3,4));
		assertEquals("4.0 + (3/4)", ff.formulaToString(op));
	}
	
	@Test
	public void testMultipleTimes(){
		ASTOperator op = new ASTTimes();
		op.addChildNode(ASTNumber.createNumber(2));
		op.addChildNode(ASTNumber.createNumber(1));
		op.addChildNode(ASTNumber.createNumber(3));
		assertEquals("2 * 1 * 3", ff.formulaToString(op));
	}
	
	@Test
	public void testDivide(){
		ASTOperator op = new ASTDivide();
		op.addChildNode(ASTNumber.createNumber(4.0));
		op.addChildNode(ASTNumber.createNumber(3,4));
		assertEquals("4.0 / (3/4)", ff.formulaToString(op));
	}
	@Test
	public void testExpoenentials(){
		ASTOperator op = new ASTTimes();
		op.addChildNode(ASTNumber.createNumber(2,5d));
		op.addChildNode(ASTNumber.createNumber(2,5d));
		assertEquals("(2.0 * pow(10, 5.0)) * (2.0 * pow(10, 5.0))", ff.formulaToString(op));
	}
	
	@Test
	public void testGroupingOfDivides(){
		//3 / (3 / 5);
		ASTOperator op = new ASTDivide();
		ASTOperator c2 = new ASTDivide();
		op.addChildNode(ASTNumber.createNumber(3));
		op.addChildNode(c2);
		c2.addChildNode(ASTNumber.createNumber(3));
		c2.addChildNode(ASTNumber.createNumber(5));
		assertEquals("3 / (3 / 5)", ff.formulaToString(op));		
	}
	
	@Test
	public void testGroupingOfMinus(){
		//3 / (3 / 5);
		ASTOperator op = new ASTMinus();
		ASTOperator c2 = new ASTMinus();
		op.addChildNode(ASTNumber.createNumber(3));
		op.addChildNode(c2);
		c2.addChildNode(ASTNumber.createNumber(3));
		c2.addChildNode(ASTNumber.createNumber(5));
		assertEquals("3 - (3 - 5)", ff.formulaToString(op));		
	}
	
	@Test
	public void testGroupingOfTimesAndPlus(){
		// (3 + 5) * 3; ==24
		ASTOperator op = new ASTTimes();
		ASTOperator c2 = new ASTPlus();
		op.addChildNode(c2);
		op.addChildNode(ASTNumber.createNumber(3));
		c2.addChildNode(ASTNumber.createNumber(3));
		c2.addChildNode(ASTNumber.createNumber(5));
		assertEquals("(3 + 5) * 3", ff.formulaToString(op));
		assertEquals(24, op.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);	
	}
	
	
	@Test
	public void testSqrt(){
		//3 / (3 / 4);
		ASTFunction f1 = ASTFunction.createFunctionNode(ASTFunctionType.ROOT);
		f1.addChildNode(ASTNumber.createNumber(2));
		f1.addChildNode(ASTNumber.createNumber(25));
		assertEquals("root(2, 25)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testTrig(){
		ASTFunction f1 = ASTFunction.createFunctionNode(ASTFunctionType.SIN);
		f1.addChildNode(ASTNumber.createNumber(2));
		assertEquals("sin(2)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testLog(){
		ASTFunction f1 = ASTFunction.createFunctionNode(ASTFunctionType.LOG);
		f1.addChildNode(ASTNumber.createNumber(100));
		assertEquals("log(100)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testLn(){
		ASTFunction f1 = ASTFunction.createFunctionNode(ASTFunctionType.LN);
		f1.addChildNode(ASTNumber.createNumber(100));
		assertEquals("ln(100)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testPower(){
		ASTFunction f1 = new ASTPower();;
		f1.addChildNode(ASTNumber.createNumber(2));
		f1.addChildNode(ASTNumber.createNumber(3));
		assertEquals("pow(2, 3)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testExp(){
		//3 / (3 / 4);
		ASTFunction f1 = ASTFunction.createFunctionNode(ASTFunctionType.EXP);
		f1.addChildNode(ASTNumber.createNumber(100));
		assertEquals("exp(100)", ff.formulaToString(f1));		
	}
	
	@Test
	public void testGrouping(){
		//3 / (3 / 4);
		ASTOperator op = new ASTDivide();
		ASTOperator op2 = new ASTPlus();
		ASTOperator op3 = new ASTTimes();
		op2.addChildNode(ASTNumber.createNumber(10));
		op2.addChildNode(ASTNumber.createNumber(20));
		op3.addChildNode(ASTNumber.createNumber(30));
		op3.addChildNode(ASTNumber.createNumber(40));
		op.addChildNode(op2);
		op.addChildNode(op3);
		assertEquals("(10 + 20) / (30 * 40)", ff.formulaToString(op));		
	}
	
	
	@Test
	public void testMultiply(){
		ASTOperator op = new ASTTimes();
		op.addChildNode(ASTNumber.createNumber(2,5));
		op.addChildNode(ASTNumber.createNumber(3,4));
		assertEquals("(2/5) * (3/4)", ff.formulaToString(op));
	}
	
	
	
	@Test
	public void testBinaryMinus(){
		ASTOperator op = new ASTMinus();
		op.addChildNode(ASTNumber.createNumber(4.0));
		op.addChildNode(ASTNumber.createNumber(3,4));
		assertEquals("4.0 - (3/4)", ff.formulaToString(op));
	}
	
	@Test
	public void testUnaryMinus(){
		ASTOperator op = new ASTMinus();
		op.addChildNode(ASTNumber.createNumber(4.0));
		assertEquals("-4.0", ff.formulaToString(op));
	}
	
	@Test
	public void testLogical(){
//		ASTRelational op = new ASTRelational(ASTRelationalType.EQ);
//		op.addChildNode(ASTNumber.createNumber(4));
//		op.addChildNode(ASTNumber.createNumber(4));
//		assertEquals("eq(4, 4)", ff.SBML_formulaToString(op));
	}
	
	@Test
	public void testSymbol(){
		ASTSymbol op = new ASTSymbol("min");
		op.addChildNode(new ASTCi("x"));
		
		assertEquals("min(x)", ff.formulaToString(op));
	}

}
