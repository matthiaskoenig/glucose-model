package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EnotationNumberTest {

	ENotationNumber en;
	@Before
	public void setUp() throws Exception {
		en = ASTNumber.createNumber(5.0d, 2d);
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testIsNotRational(){
		assertFalse(en.isRational());
		assertFalse(en.isInteger());
		assertTrue(en.isENotation());
	}

	@Test
	public void testGetString() {
		assertEquals("(5.0 * pow(10, 2.0))", en.getString());
	}

	@Test
	public void testGetValue() {
		assertEquals(500, en.getValue(),ASTNodeStub.TOLERANCE);
	}

	@Test
	public void testGetExponent() {
		assertEquals(2d, en.getExponent(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public void testGetMantissa() {
		assertEquals(5d, en.getMantissa(),ASTNodeStub.TOLERANCE);
	}
   
	

}
