package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TokenizerTest {
    Tokenizer tok = new Tokenizer();
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testTokenize() {
		assertEquals(5, tok.tokenize("myvar1+(myvar2)").size());
	}
	@Test
	public final void testTokenizeGeq() {
		assertEquals(3, tok.tokenize("a>=b").size());
	}
	@Test
	public final void testTokenizeleq() {
		TokenStream toks = tok.tokenize("less<=more");
		assertEquals(3, toks.size());
		assertEquals("less", toks.get(0).getString());
		assertEquals("<=", toks.get(1).getString());
		assertEquals("more", toks.get(2).getString());
	}
	
	@Test
	public final void testTokenizeNot() {
		Pattern p = Pattern.compile("!(?!=)");
		Matcher m = p.matcher("!(25)");
		assertTrue(m.find());
		assertEquals("!",m.group());
		Matcher m2 = p.matcher("!=25");
		assertFalse(m.find());
	}
	
	@Test
	public final void testTokenizeNot2() {
		TokenStream toks = tok.tokenize("!(5==5)");
		assertEquals(6, toks.size());
		TokenStream toks2 = tok.tokenize("5!=5");
		assertEquals(3, toks2.size());
		
	}
	@Test
	public final void testTokenizerThrowsException() {
		final Integer EXPECTED_INDX=2;
		try {
		TokenStream toks = tok.tokenize("34?");
		
		}catch(ParseException e) {
			
			assertEquals('2', e.getMessage().charAt(e.getMessage().length()-1));
		}
		
	}

}
