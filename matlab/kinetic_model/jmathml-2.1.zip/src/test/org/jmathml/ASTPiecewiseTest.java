package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTPiecewiseTest {
	ASTPiecewise pw;

	@Before
	public void setUp() throws Exception {
		pw = new ASTPiecewise();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetString() {
		assertEquals("piecewise", pw.getString());
	}

	@Test
	public final void testHasCorrectNumberChildren() {
		assertFalse(pw.hasCorrectNumberChildren());
		pw.addChildNode(new ASTNodeStub());
		assertTrue(pw.hasCorrectNumberChildren());
	}

	@Test
	public final void testEvaluateBasic() {
		ASTNode falsePiece = createFalsePiece();

		ASTNode truePiece = createTruePiece();

		double EXPECTED = truePiece.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue();
		pw.addChildNode(falsePiece);
		pw.addChildNode(truePiece);
		assertEquals(EXPECTED, pw.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
	}

	@Test
	public final void testFalseReturnsOtherwise() {
		ASTNode falsePiece = createFalsePiece();

		ASTNode otherwise = createOtherwise();

		double EXPECTED = otherwise.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue();
		pw.addChildNode(falsePiece);
		pw.addChildNode(otherwise);
		assertEquals(EXPECTED, pw.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
	}

	@Test
	public final void testEvaluatePieceWiseUsingAbsFunction() {
		ASTNode pw = ASTNodeStub.createAbsDefinition();

		EvaluationContext ec = new EvaluationContext();
		ec.setValueFor("x", -2d);
		assertEquals(2d, pw.evaluate(ec).getValue(), 0.001); // should be
																// abs(-2)=2;

		ec = new EvaluationContext();
		ec.setValueFor("x", 0d);
		assertEquals(0d, pw.evaluate(ec).getValue(), 0.001); // should be
																// abs(0)=0;

		ec = new EvaluationContext();
		ec.setValueFor("x", 5d);

		assertEquals(5d, pw.evaluate(ec).getValue(), 0.001); // should be
																// abs(5)=5;

	}

	@Test
	public final void testFalseWithNoOtherwiseReturnsNaN() {
		ASTNode falsePiece = createFalsePiece();
		pw.addChildNode(falsePiece); // no piece evaluates to true, no other
										// value
		assertEquals(Double.NaN, pw.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
	}

	private ASTNode createOtherwise() {
		ASTOtherwise other = new ASTOtherwise();
		other.addChildNode(ASTNumber.createNumber(43));
		return other;
	}

	private ASTNode createTruePiece() {
		ASTNode truePiece = new ASTPiece();
		truePiece.addChildNode(ASTNumber.createNumber(0.5));
		truePiece.addChildNode(ASTPieceTest.createTrueRelation());
		return truePiece;
	}

	private ASTNode createFalsePiece() {
		ASTNode falsePiece = new ASTPiece();
		falsePiece.addChildNode(ASTNumber.createNumber(0));
		falsePiece.addChildNode(ASTPieceTest.createFalseRelation());
		return falsePiece;
	}

}
