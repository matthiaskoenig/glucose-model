package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EvaluationContextTest {

	EvaluationContext context;
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testEvaluationContextImmutableOnceCreated() {
		Map<String, Iterable<Double>> map = new HashMap<String, Iterable<Double>>();
		map.put("a", Arrays.asList(1d));
		map.put("b", Arrays.asList(2d));
		context=new EvaluationContext(map);
		assertTrue(context.hasValueFor("a"));
		// now clear client map
		map.clear();
		// context unaffected
		assertTrue(context.hasValueFor("a"));
	}

	@Test
	public final void testGetValueFor() {
		Map<String, Iterable<Double>> map = new HashMap<String, Iterable<Double>>();
		map.put("a", Arrays.asList(1d));
		map.put("b", Arrays.asList(2d));
		context=new EvaluationContext(map);
		assertEquals(1d, context.getValueFor("a").iterator().next(), 0.001 );
	}

	@Test
	public final void testHasValueFor() {
		Map<String, Iterable<Double>> map = new HashMap<String, Iterable<Double>>();
		map.put("a", Arrays.asList(1d));
		map.put("b", Arrays.asList(2d));
		context=new EvaluationContext(map);
		assertTrue(context.hasValueFor("a"));
		assertFalse(context.hasValueFor("UNKNOWN"));
	}

}
