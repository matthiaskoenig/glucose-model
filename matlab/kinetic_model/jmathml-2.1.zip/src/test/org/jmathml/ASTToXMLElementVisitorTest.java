package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jmathml.ASTFunction.ASTFunctionType;
import org.jmathml.ASTLogical.ASTLogicalType;
import org.jmathml.ASTRelational.ASTRelationalType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTToXMLElementVisitorTest {
	
	ASTToXMLElementVisitor visitor; 
	static Namespace NS = Namespace.getNamespace("math","http://www.w3.org/1998/Math/MathML");
	@Before
	public void setUp() throws Exception {
		visitor = new ASTToXMLElementVisitor();
	}

	@After
	public void tearDown() throws Exception {
		visitor.clear();
	}

	@Test
	public final void testVisitASTOperator1() {
		
		// 4 + 5 
		ASTRootNode root = new ASTRootNode();
		ASTPlus plus = new ASTPlus();
		root.addChildNode(plus);
		plus.addChildNode(ASTNumber.createNumber(4d));
		plus.addChildNode(ASTNumber.createNumber(5d));
		root.accept(visitor);
		System.out.println(getElementString(visitor.getElement()));
	}
	
	@Test
	public final void testVisitASTOperator2() {
		
		// 4 + sin(5) 
		ASTRootNode root = new ASTRootNode();
		ASTPlus plus = new ASTPlus();
		root.addChildNode(plus);
		plus.addChildNode(ASTNumber.createNumber(4d));
		ASTNode sine = ASTFunction.createFunctionNode(ASTFunctionType.SIN);
		plus.addChildNode(sine);
		sine.addChildNode(ASTNumber.createNumber(3,4));
		root.accept(visitor);
		System.out.println(getElementString(visitor.getElement()));
	}


	@Test
	public final void testVisitASTRootNode() {
		ASTRootNode root = new ASTRootNode();
		root.accept(visitor);
		System.out.println(getElementString(visitor.getElement()));
	}
	
	@Test
	public void testRationalVisitor() {
		ASTRootNode root=new ASTRootNode();
		
		ASTNumber num = ASTNumber.createNumber(3, 4);
		root.addChildNode(num);
		root.accept(visitor);
		System.out.println(getElementString(visitor.getElement()));
		Element cn = visitor.getElement().getChild("cn",NS);
		assertNotNull(cn.getChild("sep"));
		assertEquals("34", cn.getText());
		assertEquals("rational", cn.getAttribute("type").getValue());
	}
	
	@Test
	public void testIntegerVisitor() {
		ASTNumber num = ASTNumber.createNumber(33);
		num.accept(visitor);
		Element cn = visitor.getElement().getChild("cn",NS);
		assertNull(cn.getChild("sep"));
		assertEquals("33", cn.getText());
		assertEquals("integer", cn.getAttribute("type").getValue());
	}
	
	@Test
	public void testEnotationVisitor() {
		ASTNumber num = ASTNumber.createNumber(3.2, 4);
		num.accept(visitor);
		Element cn = visitor.getElement().getChild("cn",NS);
		assertNotNull(cn.getChild("sep"));
		assertEquals("3.24.0", cn.getText());
		assertEquals("e-notation", cn.getAttribute("type").getValue());
	}
    
	

	@Test
	public final void testVisitASTFunction() {
		ASTFunction ceil = ASTFunction.createFunctionNode(ASTFunctionType.CEIL);
		ceil.addChildNode(ASTNumber.createNumber(4));
		ceil.accept(visitor);
		Element apply = visitor.getElement().getChild("apply",NS);
		assertEquals("4", apply.getChild("cn",NS).getText());	
	}
	
	@Test
	public final void testVisitASTRoot() {
		ASTFunction sqrRoot = ASTFunction.createFunctionNode(ASTFunctionType.ROOT);
		sqrRoot.addChildNode(ASTNumber.createNumber(3));
		sqrRoot.addChildNode(ASTNumber.createNumber(81));
		sqrRoot.accept(visitor);
		Element apply = visitor.getElement().getChild("apply",NS);
		assertEquals("81", apply.getChild("cn",NS).getText());	
	}
	
	
	@Test
	public final void testVisitRelational() {
		ASTRelational  rel = createTrueInequality();
		rel.accept(visitor);
		Element apply = visitor.getElement().getChild("apply",NS);
		Element geq = apply.getChild("geq",NS);
		assertEquals("geq", geq.getName());
		assertEquals(3, apply.getChildren().size());
	}
	
	@Test
	public final void testSymbolValue() {
		ASTSymbol symbol = new ASTSymbol("test",true);
		symbol.accept(visitor);
		Element symEl = visitor.getElement().getChild("csymbol",NS);
		
		assertEquals("csymbol", symEl.getName());
		assertEquals(0, symbol.getNumChildren());
	}
	
	ASTRelational createTrueInequality (){
		ASTRelational  rel = new ASTRelational(ASTRelationalType.GEQ);
		rel.addChildNode(ASTNumber.createNumber(4));
		rel.addChildNode(ASTNumber.createNumber(3));
		return rel;
	}
	
	@Test
	public final void testVisitLogical() {
		ASTLogical  log = new ASTLogical(ASTLogicalType.AND);
		log.addChildNode(createTrueInequality());
		log.addChildNode(createTrueInequality());
		log.accept(visitor);
		Element apply = visitor.getElement().getChild("apply",NS);
		Element and = apply.getChild("and",NS);
		assertEquals("and", and.getName());
		assertEquals(3, apply.getChildren().size());
	}

	@Test
	public final void testEndVisitASTFunction() {
		
	}

	@Test
	public final void testClear() {
		ASTCi identifiable = new ASTCi("var");
		identifiable.accept(visitor);
		
		assertEquals(1, visitor.getElement().getChildren().size());
		visitor.clear();
		assertEquals(0, visitor.getElement().getChildren().size());
		
	}

	@Test
	public final void testVisitASTIdentifiable() {
		ASTCi identifiable = new ASTCi("var");
		identifiable.accept(visitor);
		
	}
	
	@Test
	public final void testVisitASTSymbol() {
		ASTSymbol symbol = new ASTSymbol("time");
		symbol.setEncoding("text");
		symbol.setDefinitionURL("anyURL");
		symbol.accept(visitor);
		
	}
	
	@Test
	public final void testVisitASTOtherwise() {
		ASTOtherwise other = new ASTOtherwise();
		other.addChildNode(ASTNumber.createNumber(43));
		other.accept(visitor);
		Element otherEl = visitor.getElement().getChild("otherwise",NS);
		assertNotNull(otherEl);	
	}
	
	@Test
	public final void testVisitASTPieceWise() {
		ASTPiecewise pw = ASTNodeStub.createAbsDefinition();
		pw.accept(visitor);
		//System.out.println(getElementString(visitor.getElement()));
		Element pwEl = visitor.getElement().getChild("piecewise",NS);
		assertEquals(3, pwEl.getChildren().size());
		
	}
	
	@Test
	public final void testVisitASTNumberPI() {
		ASTRootNode root=new ASTRootNode();
		ASTNode plus = new ASTPlus();
		plus.addChildNode(ASTNumber.PI());
		plus.addChildNode(ASTNumber.E());
		root.addChildNode(plus);
		root.accept(visitor);
		
		System.out.println(getElementString(visitor.getElement()));
		
		Element par = visitor.getElement();
		Element apply = null;
		for (int i = 0; i<par.getChildren().size(); i++){
			apply = ((Element)par.getChildren().get(i));
		}

		assertEquals(3, apply.getChildren().size());
		
		

		
	}

	
	String getElementString (Element node) {
		Document mathDoc = new Document();
		mathDoc.setRootElement(node);
		String xmlString = xmlToString(mathDoc, false);
		return xmlString;
	   }
	
	/** Convert entire JDOM document to string
	 * @param xmlDoc
	 * @param bTrimAllWhiteSpace
	 * @return
	 */
	  String xmlToString(Document xmlDoc, boolean bTrimAllWhiteSpace) {
		XMLOutputter xmlOut = new XMLOutputter(Format.getPrettyFormat());
		
		return xmlOut.outputString(xmlDoc);		        
	}

}
