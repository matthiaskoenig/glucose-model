package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTOtherwiseTest {

	ASTNode otherwise;
	@Before
	public void setUp() throws Exception {
		otherwise = new ASTOtherwise();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetString() {
		assertEquals("otherwise", otherwise.getString());
		assertEquals("otherwise", otherwise.getName());
	}

	@Test
	public final void testOtherwiseShouldHaveOneChild() {
		assertFalse(otherwise.hasCorrectNumberChildren());
		otherwise.addChildNode(ASTNumber.createNumber(43));
		assertTrue(otherwise.hasCorrectNumberChildren());
		otherwise.addChildNode(ASTNumber.createNumber(3));
		assertFalse(otherwise.hasCorrectNumberChildren());
	}

	@Test
	public final void testEvaluateEValuatesChild() {
		otherwise.addChildNode(ASTNumber.createNumber(43));
		assertEquals(43,otherwise.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public final void testEvaluateIgnoresAdditionalChildElements() {
		otherwise.addChildNode(ASTNumber.createNumber(43));
		otherwise.addChildNode(ASTNumber.createNumber(56));
		assertEquals(43,otherwise.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}

}
