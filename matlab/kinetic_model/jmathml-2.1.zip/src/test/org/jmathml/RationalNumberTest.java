package org.jmathml;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RationalNumberTest {
    RationalNumber rn;
	@Before
	public void setUp() throws Exception {
		rn = ASTNumber.createNumber(5, 10);
	}
	
	@Test
	public void testIsRational(){
		assertTrue(rn.isRational());
		assertFalse(rn.isInteger());
		assertFalse(rn.isENotation());
	}
	@Test
	public void testGetNumDom(){
		assertEquals(5, rn.getNumerator());
		assertEquals(10, rn.getDenominator());
	}
	
	@Test
	public void testGetValue(){
		assertEquals(0.5d, rn.getValue(), 0.001);		
	}
	
	@Test
	public void testGetString(){
		assertEquals("(5/10)", rn.getString());
		
	}

	@After
	public void tearDown() throws Exception {
	}

}
