package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTDivideTest {

	ASTNode astDivide = new ASTDivide();
	
	@Before
	public void setUp() throws Exception {
		astDivide.addChildNode(ASTNumber.createNumber(3d));
		astDivide.addChildNode(ASTNumber.createNumber(4d));
	}
	

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testShouldHaveTwoChildren(){
		assertTrue(astDivide.hasCorrectNumberChildren());
		astDivide.addChildNode(new ASTNodeStub()); // 3 now
		assertFalse(astDivide.hasCorrectNumberChildren());
		
	}

	@Test
	public void testGetName() {
		assertEquals(ASTDivide.DIVIDE_NAME, astDivide.getName());
	}

	@Test
	public void testGetString() {
		assertEquals( "/", astDivide.getString());
	}

	@Test
	public void testEvaluate() {
		assertEquals(0.75d, astDivide.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), 0.001);
	}
	
	@Test
	public void testEvaluateWithVars() {
		astDivide = new ASTDivide();
		astDivide.addChildNode(new ASTCi("a"));
		astDivide.addChildNode(new ASTCi("b"));
		
		EvaluationContext ec = new EvaluationContext();
		ec.setValueFor("a", 12);
		ec.setValueFor("b", 4);
		assertTrue(astDivide.canEvaluate(ec));
		assertEquals(3, astDivide.evaluate(ec).getValue(), 0.001);
	}

}
