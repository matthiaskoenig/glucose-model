package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.jmathml.TokenStream.TokenIterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TokenStreamTest {
	
	Tokenizer tokenizer ;
	
	String test1 = "vara+varb";
	
	String empty = "";
	
	String test1With1Parenth = "((vara+varb))";

	@Before
	public void setUp() throws Exception {
		tokenizer=new Tokenizer();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testSize() {
		TokenStream str = tokenizer.tokenize(test1);
		assertEquals(3,str.size());
	}
	
	@Test
	public final void testSublist() {
		TokenStream str = tokenizer.tokenize(test1);
		assertEquals(1,str.subList(0, 1).size());
		assertEquals(0,str.subList(0, 0).size());
		assertEquals(1,str.subList(2, 3).size());
		assertEquals(new Token("varb"),str.subList(2, 3).iterator().peek());
	}



	@Test
	public final void testIteratorPreviousNullIfIndxZero() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
		assertNull(tokIt.previous());
	}
	
	@Test
	public final void testStartsWith() {
		TokenStream str = tokenizer.tokenize(test1);
		assertFalse(str.startsWith(new Token("(")));
	}
	
	@Test
	public final void testStartsWithParenth() {
		TokenStream str = tokenizer.tokenize(test1With1Parenth);
		assertTrue(str.startsWith(new Token("(")));
		assertTrue(str.endsWith(new Token(")")));
	}
	
	
	@Test
	public final void testtrimParenths() {
		TokenStream str = tokenizer.tokenize(test1With1Parenth);
		TokenStream trimmed = str.trimExtraneousParentheses();
		assertFalse(trimmed.startsWith(new Token("(")));
		assertFalse(trimmed.endsWith(new Token(")")));
		assertEquals(3,trimmed.size());
	}
	
	@Test
	public final void testIteratorPeekNullIfAtEnd() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
		while(tokIt.hasNext()){
		  tokIt.next();
		}
		assertFalse(tokIt.hasNext());
		assertNull(tokIt.peek());
		
	}
	
	@Test
	public final void testIteratorPeek() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
		assertEquals("vara",tokIt.peek().getString() );
		assertEquals("vara",tokIt.next().getString() );
		
	}
	
	
	
	@Test
	public final void testIteratorPrevious() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
	
		assertEquals("vara",tokIt.next().getString() );
		assertNull(tokIt.previous());
		tokIt.next();
		assertEquals("vara",tokIt.previous().getString() );
		
	}
	
	@Test
	public final void testIteratorNext() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
		assertEquals("vara",tokIt.next().getString() );
	}
	
	@Test
	public final void testIteratorNextLoop() {
		TokenStream str = tokenizer.tokenize(test1);
		TokenIterator tokIt = str.iterator();
		Token tok = null;
		while(tokIt.hasNext()){
			tok =tokIt.next();
		}
		assertEquals("varb",tok.getString());
	}
	
	@Test
	public final void testEmptyStringCanBeParsed() {
		TokenStream str = tokenizer.tokenize(empty);
		TokenIterator tokIt = str.iterator();
		assertFalse(tokIt.hasNext());
		
	}

}
