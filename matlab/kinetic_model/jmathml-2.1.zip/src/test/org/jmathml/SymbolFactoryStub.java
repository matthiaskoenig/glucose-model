package org.jmathml;


 class SymbolFactoryStub extends ASTSymbolFactory{
	

		SymbolFactoryStub() {
		super("testFactory");
		// TODO Auto-generated constructor stub
	}

		@Override
		protected
		ASTSymbol createSymbol(String urlEncoding) {
			if (urlEncoding.contains("min")){
				return new ASTSymbolStub("min");
			}
			return null;
		}
		
		protected boolean canCreateSymbol(String urlEncoding) {
			return urlEncoding.contains("min");
			
		}
		
	
}
