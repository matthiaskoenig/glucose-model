package org.jmathml;

import static org.junit.Assert.assertEquals;

import org.jmathml.ASTLogical.ASTLogicalType;
import org.jmathml.ASTRelational.ASTRelationalType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BooleanToStringTest {

	BooleanToString parser = new BooleanToString();
	ASTNode root, c1, c2, LHIeq, LH2eq, RH1eq, RH2eq;
	@Before
	public void setUp() throws Exception {
		createBaseNodeSetup();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetStringForBasicInequality() {
		assertEquals("((2.0 < 3.0 || 10.0 > 1.0) || (2.0 < 13.0 && 10.0 > 7.0))",parser.getString(root));
		assertEquals("(2.0 < 3.0 || 10.0 > 1.0)",parser.getString(c1));
		assertEquals("(2.0 < 13.0 && 10.0 > 7.0)",parser.getString(c2));
		assertEquals("10.0 > 7.0",parser.getString(RH2eq));
	}
	

	@Test
	(expected=IllegalArgumentException.class)
	public void testGetStringThrowsIAEIfnotLogicalOrRelationalType() {
	    ASTNode notLogical = new ASTNodeStub(){
	    	public boolean isLogical(){
	    		return false;
	    	}
	    };
		assertEquals("10.0 > 7.0",parser.getString(notLogical));
	}
	
	@Test
	public void testGetStringWithChildLessNode() {
	    ASTNode notLogical = new ASTNodeStub(){
	    	public boolean isLogical(){
	    		return true;
	    	}
	    };
		assertEquals("",parser.getString(notLogical));
	}
	
	private void createBaseNodeSetup(){
		// creates inequality like this:
		// ((2.0 < 3.0 || 10.0 > 1.0) || (2.0 < 13.0 && 10.0 > 7.0))
		LHIeq= new ASTRelational(ASTRelationalType.LT);
		LHIeq.addChildNode(ASTNumber.createNumber(2.0));
		LHIeq.addChildNode(ASTNumber.createNumber(3.0));
		
		 RH1eq= new ASTRelational(ASTRelationalType.GT);
		RH1eq.addChildNode(ASTNumber.createNumber(10.0));
		RH1eq.addChildNode(ASTNumber.createNumber(1.0));
		 root = new ASTLogical(ASTLogicalType.OR);
		 c1 = new ASTLogical(ASTLogicalType.OR);
		c1.addChildNode(LHIeq);
		c1.addChildNode(RH1eq);
		
		
		 c2 = new ASTLogical(ASTLogicalType.AND);
		 LH2eq= new ASTRelational(ASTRelationalType.LT);
		LH2eq.addChildNode(ASTNumber.createNumber(2.0));
		LH2eq.addChildNode(ASTNumber.createNumber(13.0));
		
		 RH2eq= new ASTRelational(ASTRelationalType.GT);
		RH2eq.addChildNode(ASTNumber.createNumber(10.0));
		RH2eq.addChildNode(ASTNumber.createNumber(7.0));
		c2.addChildNode(LH2eq);
		c2.addChildNode(RH2eq);
	
		root.addChildNode(c1);
		root.addChildNode(c2);
	}
	

}
