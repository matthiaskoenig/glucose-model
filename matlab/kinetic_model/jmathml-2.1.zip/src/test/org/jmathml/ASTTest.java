package org.jmathml;


import static org.junit.Assert.assertEquals;

import org.jmathml.ASTFunction.ASTFunctionType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTTest {
    ASTNode ast, c1, c2, num1, num2;
    static final double TOLERANCE = 0.0001;
	@Before
	public void setUp() throws Exception {
		ast = new ASTRootNode();
		c1 = new ASTPlus();
		c2 = new ASTPlus();
		num1 = ASTNumber.createNumber( 2.0d);
		num2 = ASTNumber.createNumber( 3.0d);
		ast.addChildNode(c1);
		ast.addChildNode(c2);
		c2.addChildNode(num1);
		c2.addChildNode(num2);
	}
	
	@Test
	public void testTraversal(){
		ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
		c2.accept(visitor);
		System.out.println(visitor.getString());
		assertEquals("2.0 + 3.0",visitor.getString());
		assertEquals(5, c2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), TOLERANCE);
	}
	
	@Test
	public void testParentChild(){
		assertEquals(null, ast.getParentNode());
		assertEquals(ast, c1.getParentNode());
		assertEquals(c2, num2.getParentNode());
	}
	
	@Test
	public void testLevels(){
		assertEquals(0, ast.getLevel());
		assertEquals(1, c1.getLevel());
		assertEquals(2, num2.getLevel());
	}
	
	@Test
	public void testIndex(){
		assertEquals(0, c1.getIndex());
		assertEquals(1, c2.getIndex());
	}
	
	@Test
	public void testTimes(){
		//2 + 3 +7 * 8
		ASTTimes times = new ASTTimes();
		c2.addChildNode(times);
		ASTNumber t1 = ASTNumber.createNumber( 7d);
		times.addChildNode(t1);
		times.addChildNode(ASTNumber.createNumber( 8d));
		assertEquals (3, t1.getLevel() );
		ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
		c2.accept(visitor);
		System.out.println(visitor.getString());
		assertEquals("2.0 + 3.0 + 7.0 * 8.0",visitor.getString());
		assertEquals(61,c2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),TOLERANCE);
	}
	
	@Test
	public void testDivide(){
		//2.0 + 3.0 + 7.0 * 1.0 / 4.0;
		ASTTimes times = new ASTTimes();
		c2.addChildNode(times);
		ASTDivide divide = new ASTDivide();
		
		ASTNumber t1 = ASTNumber.createNumber(7d);
		times.addChildNode(t1);
		times.addChildNode(divide);
		divide.addChildNode(ASTNumber.createNumber(1d));
		divide.addChildNode(ASTNumber.createNumber(4d));
		assertEquals (3, t1.getLevel() );
		ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
		c2.accept(visitor);
		System.out.println(visitor.getString());
		assertEquals("2.0 + 3.0 + 7.0 * 1.0 / 4.0",visitor.getString());
		assertEquals(6.75, c2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), 0.01);
	}
	
	@Test
	public void testDivide2(){
	  // 1 / (4 * 5) 
	  ASTNode ast= new ASTRootNode();
	  ASTDivide div = new ASTDivide();
	  ASTTimes times1 = new ASTTimes();
	  times1.addChildNode(ASTNumber.createNumber(4d));
	  times1.addChildNode(ASTNumber.createNumber(5d));
	  div.addChildNode(ASTNumber.createNumber (1d));
	  div.addChildNode(times1);
	  ast.addChildNode(div);
	  
	  ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
	  ast.accept(visitor);
	  System.out.println(visitor.getString());
	  assertEquals("1.0 / 4.0 * 5.0",visitor.getString());
	  assertEquals(0.05, div.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(), 0.01);
	}
	
	@Test
	public void testFormatUnaryOperator(){
	  // 1 / (4 * 5) 
	 
	  ASTFunction sinast   =  ASTFunction.createFunctionNode(ASTFunctionType.SIN);
	  sinast.addChildNode(ASTNumber.createNumber(2d));
	  
	  ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
	  sinast.accept(visitor);
	  assertEquals("sin(2.0)",visitor.getString());
	  
	  ASTFunction sinast2   =  ASTFunction.createFunctionNode(ASTFunctionType.SIN);
	  ASTTimes times1 = new ASTTimes();
	  times1.addChildNode(ASTNumber.createNumber(4d));
	  times1.addChildNode(ASTNumber.createNumber(5d));
	  sinast2.addChildNode(times1);
	  visitor.clear();
	  sinast2.accept(visitor);
	  assertEquals("sin(4.0 * 5.0)",visitor.getString());

	}
	
	@Test
	public void testFormatSec(){
		
		ASTFunction secast   =  ASTFunction.createFunctionNode(ASTFunctionType.SEC);
		secast.addChildNode(ASTNumber.createNumber(2d));
		  
		  ASTToFormulaVisitor visitor = new ASTToFormulaVisitor();
		  secast.accept(visitor);
		  assertEquals("1/cos(2.0)",visitor.getString());
	
	}
	@Test
	public void testSum (){
		double d = 2.0 + 3.0 + 7.0 * 1.0 / 4.0;
		System.out.println(d);
	}

	@After
	public void tearDown() throws Exception {
	}

}
