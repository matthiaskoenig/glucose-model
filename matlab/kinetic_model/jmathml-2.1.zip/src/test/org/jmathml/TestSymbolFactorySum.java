package org.jmathml;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSymbolFactorySum {

	

	
	@Before
	public void setUp() throws Exception {
		SymbolRegistry.getInstance().addSymbolFactory(new SymbolFactoryStub());
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testCreateSymbolFromURL(){
		ASTSymbol symbol= SymbolRegistry.getInstance().createSymbolFor("min");
		assertNotNull(symbol);
	}
	
	@Test
	public void testCanEvaluateSymbol(){
		ASTSymbol symbol= SymbolRegistry.getInstance().createSymbolFor("min");
		IEvaluationContext con = IEvaluationContext.NULL_CONTEXT;
		assertFalse(symbol.canEvaluate(con));
		assertNotNull(symbol);
		ASTCi var= new ASTCi("myVar");
		symbol.addChildNode(var);
		assertFalse(symbol.canEvaluate(con));
		EvaluationContext ec = createContext("myVar");
		assertTrue(symbol.canEvaluate(ec));
	}
	
	@Test
	public void testEvaluateSymbol(){
		ASTSymbol symbol= SymbolRegistry.getInstance().createSymbolFor("min");
		ASTCi var= new ASTCi("myVar");
		symbol.addChildNode(var);
		EvaluationContext ec = createContext("myVar");
		assertTrue(symbol.canEvaluate(ec));
		assertEquals(2,symbol.evaluate(ec).getValue(),0.001);
	}

	private EvaluationContext createContext(String varName) {
		
		double [] vals = new double []{2d,3d,5d,11d};
		EvaluationContext ec = new EvaluationContext();
		ec.setValueFor(varName, vals);
		return ec;
	}

}
