package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ASTNodeFromStringParserTest {

	
	
	String infinity ="arctan(infinity)"; // = pi/2
	String pi = "sin(pi/2)"; // = 1
	String exp ="ln(exponentiale)" ; //==1
	String uknown ="myFunc(1)";
	
	File tf = new File("TestData/TestCMath_Strings.textile");
	
	
	TextToASTNodeMathParser2 parser = new TextToASTNodeMathParser2();
    Map<String,String> NAME_2_FORMULA=new TreeMap<String, String>();
    Map<String,String> NAME_2_ANSWER=new TreeMap<String, String>();

    @BeforeClass 
    public static void beforeClass (){
    	SymbolRegistry.getInstance().addSymbolFactory(new SymbolFactoryStub());
    	
    }
    
    @AfterClass 
    public static void afterClass (){
    	SymbolRegistry.getInstance().clearFactories();
    	
    }
	@Before
	public void setUp() throws Exception {
		List<String>lines = FileUtils.readLines(tf);
		for (String line: lines) {
			if (line.contains("//") || line.matches("^$") || line.matches("^\\w+\\..*") || line.contains("@")) {
				continue;
			}
		
			String [] tokens = new String[3];
			tokens[0]=line.substring(0, line.indexOf("="));
			tokens[1]=line.substring(line.indexOf("=")+1, line.lastIndexOf("="));
			tokens[2]=line.substring(line.lastIndexOf("=")+1, line.length());
			String id = tokens[0].replaceAll("\\s", "");
			String answ = tokens[2].replaceAll("\\s", "");
			NAME_2_FORMULA.put(id, tokens[1]);
			NAME_2_ANSWER.put(id, answ);
		}
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testCurrFailure (){
		ASTNode root = new ASTRootNode();
	    parser.parseString(" ( 7-5)/ (16-8)",root);
		root.firstChild().getName();
		System.out.println(root.evaluate().getValue());
		double answer=getAnswerFor("and1");
		System.out.println(answer);
		double val = root.evaluate().getValue();
		
	}
	
	@Test
	(expected=ParseException.class)
	public void testHandlingofUnknownTokensThrowsTokenizingException (){
		ASTNode root = new ASTRootNode();
	    parser.parseString(" blh %&�@@",root);
		
	
		
		
	}
	
	@Test
	public void testAll (){
		for (String key: NAME_2_FORMULA.keySet()){
			System.err.println("Looking at " + NAME_2_FORMULA.get(key));
			ASTNode root = new ASTRootNode();
			ASTNode rc = parser.parseString(NAME_2_FORMULA.get(key),root);
			try {
				double val = root.evaluate().getValue();
				double answer=getAnswerFor(key);
			if(Math.abs(answer - val )>0.01) {
				fail("failed for " + key + "expected (" + answer + ") but was (" + val );
			}
			}catch(Exception e) {
				fail("failed for " + key);
			}
			String st = new FormulaFormatter().formulaToString(rc);
			
			ASTNode rTroot = new ASTRootNode();
			ASTNode roundTripped = parser.parseString(st,rTroot);
			try {
				double val = rTroot.evaluate().getValue();
				double answer=getAnswerFor(key);
			if(Math.abs(answer - val )>0.01) {
				fail("round trip failed for " + key);
			}
			}catch(Exception e) {
				fail("round trip failed for " + key);
			}
			
			
			
		}
	}
	
	@Test
	public void testAllWriteReadRoundTrip (){
		for (String key: NAME_2_FORMULA.keySet()){
			
			
			System.out.println("Looking at " + NAME_2_FORMULA.get(key));
			ASTNode root = new ASTRootNode();
			ASTNode rc = parser.parseString(NAME_2_FORMULA.get(key),root);
			String outString = new FormulaFormatter().formulaToString(root);
			System.out.println("Generated " + outString);
			ASTNode root2 = new ASTRootNode();
			ASTNode rc2 = parser.parseString(outString,root2);
			assertEquals("Failed on " + outString, root.evaluate().getValue(),root2.evaluate().getValue(),0.001);
			
			
		}
	}
	
	@Test
	public void testComplicated (){
		
			
			
			ASTNode root = new ASTRootNode();
			ASTNode rc = parser.parseString("2 * pow(2+3, 4 * cos(0)) / (pow(3, 4) + pow(3, 2))",root);
			String outString = new FormulaFormatter().formulaToString(root);
			System.out.println("Generated " + outString);
			ASTNode root2 = new ASTRootNode();
			ASTNode rc2 = parser.parseString(outString,root2);
			assertEquals("Failed on " + outString, root.evaluate().getValue(),root2.evaluate().getValue(),0.001);
			
		
	}

	private double getAnswerFor(String key) {
		return Double.parseDouble(NAME_2_ANSWER.get(key));
	}
	
	
	
	@Test
	public void testUnknown2() throws Exception {

		
			ASTNode root = new ASTRootNode();
		    parser.parseString("  x",root);
			root.firstChild().getName();
	   
	
	}
	
	@Test
	public void testSymbolFunctionParsing() throws Exception {
		ASTNode root = new ASTRootNode();
		 parser.parseString("min(x)",root);
		assertEquals(2, root.evaluate(createContext()).getValue(),0.001);
		
	}
	
	private EvaluationContext createContext() {
		 List<Double> results = Arrays.asList(new Double[]{2d,6d,11d,9.4});
		
	   
	    EvaluationContext ec = new EvaluationContext();
	    ec.setValueFor("x", results);
		return ec;
	}
	
	@Test
	public void testConstants() throws Exception {
       
       ASTNode root = new ASTRootNode();
	    parser.parseString(infinity,root);
		assertEquals("Parsing " + infinity, Math.PI/2, root.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		 root = new ASTRootNode();
		parser.parseString(pi,root);
		assertEquals("Parsing " + pi, 1, root.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		
		 root = new ASTRootNode();
		parser.parseString(exp,root);
		assertEquals("Parsing " + exp, 1, root.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
	}
	
	

	

}
