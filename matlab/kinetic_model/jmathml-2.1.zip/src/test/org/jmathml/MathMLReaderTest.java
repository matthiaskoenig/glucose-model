package org.jmathml;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jmathml.ASTLogical.ASTLogicalType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MathMLReaderTest {
	
	ASTSymbolFactory timeF = new ASTSymbolFactory("time") {
        
        @Override
        protected ASTSymbol createSymbol(String urlEncoding) {
           return new ASTSymbol("t",true);
        }
        
        @Override
        protected boolean canCreateSymbol(String urlEncoding) {
            return "http://www.sbml.org/sbml/symbols/time".equals(urlEncoding);
        }
    };

	/*
	 * Tests roundtripping Element->ASTNode->Element
	 */
	void assertElementsHaveSameContent(final Element el1, final Element el2) {
		String el1Name = el1.getName();
		String el2Name = el2.getName();
		assertEquals("Element names  [" + el1.getName() + "," + el2.getName()
				+ "] are not  the same", el1.getName(), el2.getName());
		assertEquals(el1Name + " and " + el2Name
				+ " have different attribute count",
				el1.getAttributes().size(), el2.getAttributes().size());

		for (int i = 0; i < el1.getAttributes().size(); i++) {
			Attribute att1 = ((Attribute) el1.getAttributes().get(i));
			assertEquals(el1Name + " and " + el2Name
					+ " have different attribute values", att1.getValue(),
					((Attribute) el2.getAttribute(att1.getName())).getValue());
		}
		
		assertEquals(el1Name + " and " + el2Name
				+ " have different number of children", el1.getChildren()
				.size(), el2.getChildren().size());
		for (int i = 0; i < el1.getChildren().size(); i++) {
			Element c1 = (Element) el1.getChildren().get(i);
			Element c2 = (Element) el2.getChildren().get(i);
			assertElementsHaveSameContent(c1, c2);
		}
	}

	private MathMLReader reader;
	
	@BeforeClass
	public static void setUpFactory() {
		SymbolRegistry.getInstance().addSymbolFactory(new SymbolFactoryStub());
	}
	
	@Before
	public void setUp() throws Exception {
		reader = new MathMLReader();
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@AfterClass
	public static void clearFactory() {
		SymbolRegistry.getInstance().clearFactories();
	}



	@Test
	public void testReadTimes() throws IOException {
		String mathml = startMath() + "<apply>" + getTimesXML() + "</apply>"
				+ endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(12, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}

	private Element getElementFromMathMlString(String mathml)
			throws IOException {
		Element math = readXML(new StringReader(mathml));
		return math;
	}
	
	/**
	 * Creates a JDOM document from the given XML string (via a Reader)
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	 public static Element readXML(Reader reader) throws IOException {
		try {
			SAXBuilder builder = new SAXBuilder(false);
			Document sDoc = builder.build(reader);
			Element root = sDoc.getRootElement();
			return root;
		}catch (JDOMException e){
			e.printStackTrace(System.out);
			throw new RuntimeException(e.getMessage());
		}
	}
	
	

	private ASTNode getASTNodeFromElement(Element math) {
		MathMLReader reader = new MathMLReader();
		ASTNode root = reader.parseMathML(math);
		return root;
	}

	@Test
	public void testReadMinus() throws IOException {
		String mathml = startMath() + "<apply>" + getMinusXML() + "</apply>"
				+ endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(-1, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}

	@Test
	public void testReadDivide() throws IOException {
		String mathml = startMath() + "<apply>" + getDivideXML() + "</apply>"
				+ endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(0.75, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	@Test
	public void testReadUnaryPlus() throws IOException {
		String mathml = startMath() + "<apply>" + " <plus /><cn type=\"integer\">34</cn>" + "</apply>"
				+ endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(34, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	(expected=RuntimeException.class)
	public void testReadUnknownSymbol() throws IOException {
		String mathml = startMath() + "<apply>" + " <plus /> <csymbol encoding=\"text\"  definitionURL=\"http://www.sbml.org/sbml/symbols/time\">time</csymbol>"
    + "</apply>"
				+ endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(34, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	
    
	
	
  


	@Test
	public void testReadRational() throws IOException {
		String mathml = startMath() + getRationalXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(0.8, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}

	@Test
	public void testReadENotation() throws IOException {
		String mathml = startMath() + getENotationXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(420000, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}

	@Test
	public void testReadCi() throws IOException {
		String mathml = startMath() + getCiXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals("a", root.firstChild().getName());
		visitAndCheckRoundTrip(math, root);
	}

	@Test
	public void testReadCsymbol() throws IOException {
		String mathml = startMath() + getCsymXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		ASTSymbol sym = (ASTSymbol) root.firstChild();
		assertEquals("min", sym.getString());
		assertEquals("text", sym.getEncoding());
		assertEquals("min", sym.getDefinitionURL());
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadCAppliesNameCorrectly() throws IOException {
	String normal = startMath()+"<apply><csymbol encoding=\"text\" definitionURL=\"min\">min</csymbol></apply>"+ endMath();
	String odd = startMath()+"<apply><csymbol encoding=\"text\" definitionURL=\"min\">minimum</csymbol></apply>" +endMath();
	
	ASTNode root = reader.parseMathMLFromString(normal);
	ASTSymbol sym = (ASTSymbol) root.firstChild();
	assertEquals("min", sym.getString());
	assertEquals("min", sym.getName());
	
	ASTNode root2 = reader.parseMathMLFromString(odd);
	ASTSymbol sym2 = (ASTSymbol) root2.firstChild();
	assertEquals("minimum", sym2.getString());
	assertEquals("minimum", sym2.getName());
	
	}
	@Test
	public void testReadCsymbolWithArguments() throws IOException {
		String mathml = startMath() + getCsymXMLWithArgs() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		ASTSymbol sym = (ASTSymbol) root.firstChild();
		visitAndCheckRoundTrip(math, root);
	}


	@Test
	public void testReadFunctionRoundTrip() throws IOException {
		String sin = "<apply><sin/>" + getCnXML(Double.toString(Math.PI/2)) +"</apply>";
		String mathml = startMath() + sin + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadLogWithBaseRoundtrip() throws IOException {
		String log = "<apply><log/><logbase><cn> 3 </cn></logbase>"+getCnXML("81")+"</apply>";
		String mathml = startMath() + log + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		visitAndCheckRoundTrip(math, root);
		
		// now try parsing from generated XML from AST
		ASTToXMLElementVisitor vis = new ASTToXMLElementVisitor();
		root.accept(vis);
		Element parsedFromGenerated =vis.getElement();
	
		// and check evaluation
		ASTNode root2 = getASTNodeFromElement(parsedFromGenerated);
		assertEquals(4, root2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		
		
	}
	
	@Test
	public void testReadLog10Roundtrip() throws IOException {
		String log = "<apply><log/>"+getCnXML("100")+"</apply>";
		String mathml = startMath() + log + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		visitAndCheckRoundTrip(math, root);
		
		// now try parsing from generated XML from AST
		ASTToXMLElementVisitor vis = new ASTToXMLElementVisitor();
		root.accept(vis);
		Element parsedFromGenerated =vis.getElement();
	
		// and check evaluation
		ASTNode root2 = getASTNodeFromElement(parsedFromGenerated);
		assertEquals(2, root2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		
		
	}
	
	@Test
	public void testReadRootWithOtherDegreeRoundtrip() throws IOException {
		String mathroot = "<apply> <root/><degree><cn> 3 </cn></degree>"+getCnXML("729")+"</apply>";
		String mathml = startMath() + mathroot + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		visitAndCheckRoundTrip(math, root);
		
		// now try parsing from generated XML from AST
		ASTToXMLElementVisitor vis = new ASTToXMLElementVisitor();
		root.accept(vis);
		Element parsedFromGenerated =vis.getElement();
	
		// and check evaluation
		ASTNode root2 = getASTNodeFromElement(parsedFromGenerated);
		assertEquals(9, root2.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),0.001);
		
		
	}
	


	@Test
	public void testReadLogicalAnd() throws IOException {
		testLogicalOrRelational(ASTLogicalType.AND);
	}
	
	@Test
	public void testReadLogicalOr() throws IOException {
		testLogicalOrRelational(ASTLogicalType.OR);
	}
	@Test
	public void testReadLogicalNot() throws IOException {
		testLogicalOrRelational(ASTLogicalType.NOT);
	}
	
	@Test
	public void testReadLogicalXOR() throws IOException {
		testLogicalOrRelational(ASTLogicalType.XOR);
	}
	
	@Test
	public void testReadRelational() throws IOException {
		testLogicalOrRelational(ASTRelational.ASTRelationalType.EQ);
		testLogicalOrRelational(ASTRelational.ASTRelationalType.NEQ);
		testLogicalOrRelational(ASTRelational.ASTRelationalType.LEQ);
		testLogicalOrRelational(ASTRelational.ASTRelationalType.GEQ);
		testLogicalOrRelational(ASTRelational.ASTRelationalType.LT);
		testLogicalOrRelational(ASTRelational.ASTRelationalType.GT);
	}

	private void testLogicalOrRelational(ASTTypeI logical) throws IOException {
		String mathml = startMath() + getLogicalXML(logical) + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		visitAndCheckRoundTrip(math, root);
	}

	private String getLogicalXML(ASTTypeI logical) {
		return  "<apply>"+"<" + logical.toString().toLowerCase()+"/>" + getRationalXML() + getRationalXML()+"</apply>";
	}

	private String getCsymXML() {
		return "<apply><csymbol encoding=\"text\" definitionURL=\"min\">min</csymbol></apply>";
	}

	
	private String getCsymXMLWithArgs() {
		return "<apply><csymbol encoding=\"text\" definitionURL=\"min\">min</csymbol>"+getCiXML()+"</apply>";
	}
	@Test
	public void testReadReal() throws IOException {
		String mathml = startMath() + getRealXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(4.2, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadPi() throws IOException {
		String mathml = startMath() + getPiXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(Math.PI, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadE() throws IOException {
		String mathml = startMath() + getEXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(Math.E, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadNan() throws IOException {
		String mathml = startMath() + getNaNXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(Double.NaN, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testReadInfinity() throws IOException {
		String mathml = startMath() + getInfinityXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(Double.POSITIVE_INFINITY, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testFunction() throws IOException {
		String mathml = startMath() + getSinXML() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		assertEquals(1, root.evaluate(IEvaluationContext.NULL_CONTEXT)
				.getValue(), 0.001);
		visitAndCheckRoundTrip(math, root);
	}
	
	@Test
	public void testLF() throws IOException {
		String mathml = startMath() + getLF() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
	//	System.err.println(new FormulaFormatter().formulaToString(root));
	
	}
	
	@Test
	public void testSymbolValue() throws IOException {
		setUpTime();
		String mathml = startMath() + getSymbolValue() + endMath();
		Element math = getElementFromMathMlString(mathml);
		ASTNode root = reader.parseMathMLFromString(mathml);
		EvaluationContext ec = new EvaluationContext();
		ec.setValueFor("t", 34);
		assertEquals(ASTNumber.TRUE().getValue(), root.evaluate(ec).getValue(),0.001);
		SymbolRegistry.getInstance().removeSymbolFactory(timeF);
	}
	
	void setUpTime (){
		
SymbolRegistry.getInstance().addSymbolFactory(timeF);
	}

	private String getSinXML() {
		return "<apply><sin/>" + "<cn type=\"real\">1.57</cn></apply>";
	}

	private String getInfinityXML() {
		return "<cn type=\"real\">infinity</cn>";
	}

	private String getNaNXML() {
		return "<cn type=\"real\">notanumber</cn>";
	}

	private String getEXML() {
		return "<cn type=\"real\">exponentiale</cn>";
	}

	private String getPiXML() {
		return "<cn type=\"real\">pi</cn>";
	}

	private String getRealXML() {
		return "<cn type=\"real\">4.2</cn>";
	}

	private String getENotationXML() {
		return "<cn type=\"e-notation\">4.2<sep/>5</cn>";
	}

	private void visitAndCheckRoundTrip(Element math, ASTNode root) {
		ASTToXMLElementVisitor vis = new ASTToXMLElementVisitor();
		root.accept(vis);
		assertElementsHaveSameContent(math, vis.getElement());
	}

	private String getRationalXML() {
		return "<cn type=\"rational\">4<sep/>5</cn>";
	}

	private String getCiXML() {
		return "<ci> a </ci>";
	}
	
	private String getSymbolValue(){
		return" <math:apply xmlns:math=\"http://www.w3.org/1998/Math/MathML\">"+
		    "<math:gt />"+
		    "<math:csymbol definitionURL=\"http://www.sbml.org/sbml/symbols/time\" encoding=\"text\">t</math:csymbol>"+
		    "<math:cn type=\"real\">24.0</math:cn>"+
		 " </math:apply>";
	}
	
	private String getLF (){
		return  "<apply>"+ 
		"<plus />"+  
		"<apply>"+
			"<minus />"+
			"<apply>"+
				"<plus />"+
				"<ci> lightOffset </ci>"+
				"<apply>"+
					"<times />"+
					"<cn> 0.5 </cn>"+
					"<ci> lightAmplitude </ci>"+
					"<apply>"+
						"<plus />"+
						"<cn> 1 </cn>"+
						"<apply>"+
							"<tanh />"+
							"<apply>"+
								"<divide />"+
								"<apply>"+
									"<times />"+
									"<ci> cyclePeriod </ci>"+
									"<apply>"+
										"<minus />"+
										"<apply>"+
											"<divide />"+
											"<apply>"+
												"<plus />"+
												"<ci> t </ci>"+
												"<ci> phase </ci>"+
											"</apply>"+
											"<ci> cyclePeriod </ci>"+
										"</apply>"+
										"<apply>"+
											"<floor />"+
											"<apply>"+
												"<divide />"+
												"<apply>"+
													"<floor />"+
													"<apply>"+
														"<plus />"+
														"<ci> t </ci>"+
														"<ci> phase </ci>"+
													"</apply>"+
												"</apply>"+
												"<ci> cyclePeriod </ci>"+
											"</apply>"+
										"</apply>"+
									"</apply>"+
								"</apply>"+
								"<ci> twilightPeriod </ci>"+
							"</apply>"+
						"</apply>"+
					"</apply>"+
				"</apply>"+
			"</apply>"+
			"<apply>"+
				"<times />"+
				"<cn> 0.5 </cn>"+
				"<ci> lightAmplitude </ci>"+
				"<apply>"+
					"<plus />"+
					"<cn> 1 </cn>"+
					"<apply>"+
						"<tanh />"+
						"<apply>"+
							"<divide />"+
							"<apply>"+
								"<minus />"+
								"<apply>"+
									"<times />"+
									"<ci> cyclePeriod </ci>"+
									"<apply>"+
										"<minus />"+
										"<apply>"+
											"<divide />"+
											"<apply>"+
												"<plus />"+
												"<ci> t </ci>"+
												"<ci> phase </ci>"+
											"</apply>"+
											"<ci> cyclePeriod </ci>"+
										"</apply>"+
										"<apply>"+
											"<floor />"+
											"<apply>"+
												"<divide />"+
												"<apply>"+
													"<floor />"+
													"<apply>"+
														"<plus />"+
														"<ci> t </ci>"+
														"<ci> phase </ci>"+
													"</apply>"+
												"</apply>"+
												"<ci> cyclePeriod </ci>"+
											"</apply>"+
										"</apply>"+
									"</apply>"+
								"</apply>"+
								"<ci> photoPeriod </ci>"+
							"</apply>"+
							"<ci> twilightPeriod </ci>"+
						"</apply>"+
					"</apply>"+
				"</apply>"+
			"</apply>"+
		"</apply>"+
		"<apply>"+
			"<times />"+
			"<cn> 0.5 </cn>"+
			"<ci> lightAmplitude </ci>"+
			"<apply>"+
				"<plus />"+
				"<cn> 1 </cn>"+
				"<apply>"+
					"<tanh />"+
					"<apply>"+
						"<divide />"+
						"<apply>"+
							"<minus />"+
							"<apply>"+
								"<times />"+
								"<ci> cyclePeriod </ci>"+
								"<apply>"+
									"<minus />"+
									"<apply>"+
										"<divide />"+
										"<apply>"+
											"<plus />"+
											"<ci> t </ci>"+
											"<ci> phase </ci>"+
										"</apply>"+
										"<ci> cyclePeriod </ci>"+
									"</apply>"+
									"<apply>"+
										"<floor />"+
										"<apply>"+
											"<divide />"+
											"<apply>"+
												"<floor />"+
												"<apply>"+
													"<plus />"+
													"<ci> t </ci>"+
													"<ci> phase </ci>"+
												"</apply>"+
											"</apply>"+
											"<ci> cyclePeriod </ci>"+
										"</apply>"+
									"</apply>"+
								"</apply>"+
							"</apply>"+
							"<ci> cyclePeriod </ci>"+
						"</apply>"+
						"<ci> twilightPeriod </ci>"+
					"</apply>"+
				"</apply>"+
			"</apply>"+
		"</apply>"+
	"</apply>";
	}
	
	private String getCnXML(String val) {
		return "<cn type=\"real\">" + val +"</cn>";
	}

	private String getMinusXML() {
		return "<minus/>" + "<cn type=\"integer\">3</cn>"
				+ "<cn type=\"integer\">4</cn>";
	}

	private String getDivideXML() {
		return "<divide/>" + "<cn type=\"integer\">3</cn>"
				+ "<cn type=\"integer\">4</cn>";
	}

	private String endMath() {
		return "</math>";
	}

	private String startMath() {
		return "<math xmlns=\"http://www.w3.org/1998/Math/MathML\">";
	}

	private String getTimesXML() {
		return "<times/>" + "<cn type=\"integer\">3</cn>"
				+ "<cn type=\"integer\">4</cn>";
	}

}
