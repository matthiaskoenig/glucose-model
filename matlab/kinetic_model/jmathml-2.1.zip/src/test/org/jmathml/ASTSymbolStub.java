package org.jmathml;

public class ASTSymbolStub extends ASTSymbol {
	

		public ASTSymbolStub(String id) {
			super(id);
			setEncoding("text");
			setDefinitionURL("org.mathml/#test");
			// TODO Auto-generated constructor stub
		}
		
	
		
		/**
		 * 
		 */
		public boolean hasCorrectNumberChildren() {
			return getNumChildren() ==1;
		}
		
		@Override
		 protected ASTNumber doEvaluate(IEvaluationContext context) {
			double rc = Double.MAX_VALUE;
			for (Double val: context.getValueFor(firstChild().getName())){
				rc = val < rc ?val:rc;
			}
			return ASTNumber.createNumber(rc);
		}
		
		protected boolean subclassCanEvaluate(IEvaluationContext context){
			if(firstChild().isVariable() && context.hasValueFor(firstChild().getName())) {
				return true;
			}
			return false;
		}
		
	
		
		

	
}
