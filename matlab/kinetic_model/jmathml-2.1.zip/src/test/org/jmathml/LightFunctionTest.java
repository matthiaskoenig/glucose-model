package org.jmathml;

import java.io.File;
import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.sbml.libsbml.Event;
import org.sbml.libsbml.EventAssignment;
import org.sbml.libsbml.FunctionDefinition;
import org.sbml.libsbml.ListOfFunctionDefinitions;
import org.sbml.libsbml.Model;
import org.sbml.libsbml.SBMLDocument;
import org.sbml.libsbml.Trigger;
import org.sbml.libsbml.libsbml;
/*
 * Test execution of complef function
 */
public class LightFunctionTest {
	
// Uncommment this to load libsbml from wherever
//	 static String FRAGMENT_LOCATION = "../uk.ac.ed.csb.libsbml." + "macosx"
//	            + "/os/" + "macosx";
//	    static File f = new File(FRAGMENT_LOCATION);
//	    static {
//	        System.load(f.getAbsolutePath() + "/libxml2.2.dylib");
//	        System.load(f.getAbsolutePath() + "/libsbml.3.4.0.dylib");
//	        System.load(f.getAbsolutePath() + "/libsbmlj.jnilib");
//	    }

	 
	    File Light = new File("TestData/BasicLight.xml");
	    ASTSymbolFactory timeFactory =new ASTSymbolFactory("time") {

            @Override
            protected ASTSymbol createSymbol(String urlEncoding) {
                return new ASTSymbol("t", true);
            }

            @Override
            protected boolean canCreateSymbol(String urlEncoding) {
                return "http://www.sbml.org/sbml/symbols/time"
                        .equals(urlEncoding);
            }
        };

	    @Before
	    public void setUp() throws Exception {
	        SymbolRegistry.getInstance().addSymbolFactory(timeFactory);
	                
	    }

	@After
	public void tearDown() throws Exception {
		 SymbolRegistry.getInstance().removeSymbolFactory(timeFactory);
	}

	
	
	 @Test
	 @Ignore
	    public void testEvaluateLightFunction() throws IOException {
	        SBMLDocument light = libsbml.readSBML(Light.getAbsolutePath());
	        Model m = light.getModel();
	        ListOfFunctionDefinitions lofd = m.getListOfFunctionDefinitions();
	        for (long i = 0; i < lofd.size(); i++) {
	            FunctionDefinition fd = lofd.get(i);
	           
	            ASTNode root = convertSBMLMathToJavaMath(fd.getMath());
	            
	            System.err.println(new FormulaFormatter().formulaToString(root));

	            // over each timestep
	            for (double step = 0.1; step < 100; step += 0.5) {
	                EvaluationContext ec = new EvaluationContext();
	                for (ASTCi s : root.getIdentifiers()) {
	                    if (!("t".equals(s.getString()))) {
	                        double value = m.getParameter(s.getString()).getValue();
	                        ec.setValueFor(s.getString(), value);
	                    }

	                }
	                ec.setValueFor("t", step);
	                // evaluate 7th child of function math which is the actual formula
	                ASTNumber num = root.getChildAtIndex(7).evaluate(ec);
	                // this is the output
	                System.err.println(step + "\t" + num.getValue());
	                // now check events
	                for (long j = 0; j < m.getListOfEvents().size(); j++) {

	                    Event eve = m.getListOfEvents().get(j);
	                    Trigger trig = eve.getTrigger();
	                   
	                    // check triggers which we know are just time dependent
	                    ASTNode root3 = convertSBMLMathToJavaMath(trig.getMath());
	                    EvaluationContext e2 = new EvaluationContext();
	                    e2.setValueFor("t", step);
	                    

	                    // if triggered
	                    if (root3.evaluate(e2).isTruth()) {
	                        // now do assignments
	                        for (long k = 0; k < eve.getNumEventAssignments(); k++) {
	                            EventAssignment ea = eve.getEventAssignment(k);
	                            String var = ea.getVariable();
	                            ASTNode rootAssign =convertSBMLMathToJavaMath(ea.getMath());
	                            // evaluate assignment statements
	                            EvaluationContext ec3 = new EvaluationContext();
	                            for (ASTCi s : rootAssign.getIdentifiers()) {
	                                // assume we're just using parameters but this may
	                                // not be valid. T is not a parameter so must be defined
	                                // separately.
	                                if (!("t".equals(s.getString()))) {
	                                    double value = m
	                                            .getParameter(s.getString())
	                                            .getValue();
	                                    ec3.setValueFor(s.getString(), value);
	                                }

	                            }
	                            ec3.setValueFor("t", step);
	                            // assume we're assigning a parameter value.
	                            if (m.getParameter(var) != null) {
	                                m.getParameter(var).setValue(
	                                        rootAssign.evaluate(ec3).getValue());
	                            }

	                        }
	                    }
	                }

	            }
	        }

	    }
	  public ASTNode convertSBMLMathToJavaMath(org.sbml.libsbml.ASTNode sbmlmath) throws IOException{
	        String mathmlAssign = libsbml
	                .writeMathMLToString(sbmlmath);

	        ASTNode rootAssign = new MathMLReader()
	                .parseMathMLFromString(mathmlAssign);
	        return rootAssign;
	    }

	    String getElementString(Element node) {
	        Document mathDoc = new Document();
	        mathDoc.setRootElement(node);
	        String xmlString = xmlToString(mathDoc, false);
	        return xmlString;
	    }

	    String xmlToString(Document xmlDoc, boolean bTrimAllWhiteSpace) {
	        XMLOutputter xmlOut = new XMLOutputter(Format.getPrettyFormat());

	        return xmlOut.outputString(xmlDoc);
	    }

}
