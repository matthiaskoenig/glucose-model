package org.jmathml;

import org.jmathml.ASTRelational.ASTRelationalType;


/*
 * Test stub class for general AST operations
 */
public class ASTNodeStub extends ASTNode {

	static final double TOLERANCE=0.0001;
	ASTNodeStub() {
		super(ASTType.ROOTNODE);// TODO Auto-generated constructor stub
		setName("test");
	}

	@Override
	 boolean doAccept(ASTVisitor v) {
		return true;
	}

	public ASTNumber doEvaluate(IEvaluationContext context) {return ASTNumber.AST_NULL_NUMBER;}

	

	@Override
	public String getString() {
	return "Test";
	}

	@Override
	public boolean hasCorrectNumberChildren() {
		return true;
	}

	@Override
	public boolean isNumber() {	
		return false;
	}

	@Override
	public boolean isFunction() {
		return false;
	}

	@Override
	public boolean isLambda() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isLogical() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isRelational() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public static  ASTPiecewise createAbsDefinition() {
		
		ASTNode lt = new ASTRelational(ASTRelationalType.LT);
		lt.addChildNode(new ASTCi("x"));
		lt.addChildNode(ASTNumber.createNumber(0));
		ASTMinus minus = new ASTMinus();
		minus.addChildNode(new ASTCi("x"));
		ASTPiece p1 = new ASTPiece();
		p1.addChildNode(minus);
		p1.addChildNode(lt);
		
		
		ASTNode eq = new ASTRelational(ASTRelationalType.EQ);
		eq.addChildNode(new ASTCi("x"));
		eq.addChildNode(ASTNumber.createNumber(0));
		
		
		ASTPiece p2 = new ASTPiece();
		p2.addChildNode(ASTNumber.createNumber(0));
		p2.addChildNode(eq);
	
		ASTNode gt = new ASTRelational(ASTRelationalType.GT);
		gt.addChildNode(new ASTCi("x"));
		gt.addChildNode(ASTNumber.createNumber(0));
		
		ASTPiece p3 = new ASTPiece();
		p3.addChildNode(new ASTCi("x"));
		p3.addChildNode(gt);
		ASTPiecewise pw= new ASTPiecewise();
		pw.addChildNode(p1);
		pw.addChildNode(p2);
		pw.addChildNode(p3);
		return pw;
		}

	
}
