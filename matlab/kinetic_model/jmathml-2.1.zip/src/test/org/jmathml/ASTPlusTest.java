package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTPlusTest {

	ASTNode astPlus = new ASTPlus();
	
	@Before
	public void setUp() throws Exception {
		astPlus.addChildNode(ASTNumber.createNumber(3d));
		astPlus.addChildNode(ASTNumber.createNumber(7d));
	}
	

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetName() {
		assertEquals(ASTPlus.PLUS_NAME, astPlus.getName());
	}

	@Test
	public void testGetString() {
		assertEquals( "+", astPlus.getString());
	}

	@Test
	public void testEvaluate() {
		assertEquals(10d, astPlus.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public void testShouldHaveAtLeastTwoChildren(){
		assertTrue(astPlus.hasCorrectNumberChildren());
		astPlus.addChildNode(new ASTNodeStub()); // 3 now
		assertTrue(astPlus.hasCorrectNumberChildren());
		
		astPlus= new ASTPlus();
		assertFalse(astPlus.hasCorrectNumberChildren());
		astPlus.addChildNode(new ASTNodeStub()); // 1 now
		assertTrue(astPlus.hasCorrectNumberChildren());
		
		
	}

}
