package org.jmathml;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SymbolRegistryTest {

	SymbolRegistry sr = SymbolRegistry.getInstance();
	@Before
	public void setUp() throws Exception {
		sr.clearFactories();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testAddSymbolFactory() {
		assertTrue(sr.addSymbolFactory(new SymbolFactoryStub()));
		assertFalse(sr.addSymbolFactory(new SymbolFactoryStub()));
		
	}

}
