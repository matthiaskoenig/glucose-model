package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTMinusTest {

	ASTNode minus = new ASTMinus();
	ASTNode minus2 = new ASTMinus();
	
	@Before
	public void setUp() throws Exception {
		minus.addChildNode(ASTNumber.createNumber(7d));
		minus.addChildNode(ASTNumber.createNumber(3d));
	}
	

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetName() {
		assertEquals(ASTMinus.MINUS_NAME, minus.getName());
	}

	@Test
	public void testGetString() {
		assertEquals( "-", minus.getString());
	}

	@Test
	public void testEvaluate() {
		assertEquals(4d, minus.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public void testBinaryMinusShouldHaveExactlyTwoChildren(){
		assertTrue(minus.hasCorrectNumberChildren());
		minus.addChildNode(new ASTNodeStub()); // 3 now
		assertFalse(minus.hasCorrectNumberChildren());
		
		minus= new ASTMinus();
		assertFalse(minus.hasCorrectNumberChildren());
		
		
	}

}
