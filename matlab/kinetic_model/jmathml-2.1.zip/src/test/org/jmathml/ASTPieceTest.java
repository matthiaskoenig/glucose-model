package org.jmathml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.jmathml.ASTRelational.ASTRelationalType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTPieceTest {
	ASTPiece piece;
	@Before
	public void setUp() throws Exception {
		piece =  new ASTPiece();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetString() {
		assertEquals("piece", piece.getString());
		assertEquals("piece", piece.getName());
	}

	@Test
	public final void testHasCorrectNumberChildren() {
		for (int i = 1; i< 10; i++){
			piece.addChildNode(new ASTNodeStub());
			if (i!=2) {
				assertFalse(piece.hasCorrectNumberChildren());
			} else
				assertTrue(piece.hasCorrectNumberChildren());
		}
	}

	@Test
	public final void testEvaluateReturnsValueIfConditionTrue() {
		piece.addChildNode(ASTNumber.createNumber(4.0));
		piece.addChildNode(createTrueRelation());
		assertEquals(4.0, piece.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),
				 ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public final void testEvaluateReturnsASTNullNumberIfConditionFalse() {
		piece.addChildNode(ASTNumber.createNumber(4.0));
		piece.addChildNode(createFalseRelation());
		assertEquals(ASTNumber.AST_NULL_NUMBER.getValue(), piece.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),
				 ASTNodeStub.TOLERANCE);
	}
	
	@Test
	public final void testEvaluateReturnsASTNullNumberIfWrongNumberOfChildren() {
		piece.addChildNode(ASTNumber.createNumber(4.0));
		piece.addChildNode(ASTNumber.createNumber(5.0)); // now has 3 children
		piece.addChildNode(createFalseRelation());
		assertEquals(ASTNumber.AST_NULL_NUMBER.getValue(), piece.evaluate(IEvaluationContext.NULL_CONTEXT).getValue(),
				 ASTNodeStub.TOLERANCE);
	}
	
	static ASTNode createFalseRelation() {
		ASTNode gt = new ASTRelational(ASTRelationalType.GEQ);
		gt.addChildNode(ASTNumber.createNumber(3));
		gt.addChildNode(ASTNumber.createNumber(4));
		return gt;
	}

	static ASTNode createTrueRelation(){
		ASTNode gt = new ASTRelational(ASTRelationalType.GEQ);
		gt.addChildNode(ASTNumber.createNumber(4));
		gt.addChildNode(ASTNumber.createNumber(3));
		return gt;
	}

}
