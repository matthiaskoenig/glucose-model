package org.jmathml;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ASTCiTest {
     ASTCi var = new ASTCi("dd");
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testIsVariable() {
		assertTrue(var.isVariable());
		assertFalse(var.isSymbol());
	}

	@Test
	public final void testCorrectNumberChildrenIsNone() {
		assertTrue(var.hasCorrectNumberChildren());
		var.addChildNode(new ASTNodeStub());
		assertFalse(var.hasCorrectNumberChildren());
	}

	@Test
	public final void testIsVectorIsFalseByDefault() {
		assertFalse(var.isVector());
	}
	
	final ASTSymbol vec = new ASTSymbol("test"){
		public boolean isVectorOperation() {
			return true;
		}
	};
	
	@Test
	public final void testIsVectorTrueIfParentNodeIsVector() {
		vec.addChildNode(var);
		assertTrue(var.isVector());
	}
	
	@Test
	public final void testIsVectorFalseIfParentNodeIsNotVector() {
		ASTPlus plus = new ASTPlus();
		plus.addChildNode(var);
		assertFalse(var.isVector());
	}
	

}
